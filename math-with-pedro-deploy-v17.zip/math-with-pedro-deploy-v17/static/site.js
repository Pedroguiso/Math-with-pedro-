
// Local preview compatibility: keep the same files navigable when opened directly.
if(window.location.protocol==='file:'){
  const mapLocal=(href)=>{
    if(!href || !href.startsWith('/')) return href;
    if(href==='/') return 'index.html';
    if(href==='/pt' || href==='/pt/') return 'pt/index.html';
    if(href==='/pt/apply') return 'pt/apply.html';
    if(href.startsWith('/pt/apply?')) return 'pt/apply.html?'+href.split('?',2)[1];
    if(href==='/pt/success') return 'pt/success.html';
    if(href.startsWith('/pt/success?')) return 'pt/success.html?'+href.split('?',2)[1];
    if(href==='/pt/privacy') return 'pt/privacy.html';
    if(href==='/pt/login') return 'pt/login.html';
    if(href.startsWith('/#')) return 'index.html'+href.slice(1);
    if(href.startsWith('/apply?')) return 'apply.html?'+href.split('?',2)[1];
    if(href.startsWith('/success?')) return 'success.html?'+href.split('?',2)[1];
    const table={
      '/apply':'apply.html','/apply.html':'apply.html',
      '/login':'login.html','/login.html':'login.html',
      '/success':'success.html','/success.html':'success.html',
      '/portal':'portal.html','/privacy':'privacy.html',
      '/logout':'index.html'
    };
    return table[href] || href;
  };
  document.addEventListener('DOMContentLoaded',()=>{
    document.querySelectorAll('a[href]').forEach(a=>{a.setAttribute('href',mapLocal(a.getAttribute('href')))});
  });
}

// Preserve acquisition attribution across the landing page -> booking flow.
(()=>{
  const keys=['utm_source','utm_medium','utm_campaign','utm_content'];
  try{
    const params=new URLSearchParams(window.location.search);
    keys.forEach(k=>{const v=params.get(k);if(v)sessionStorage.setItem('mwp_'+k,v.slice(0,160));});
    if(document.referrer){
      try{const u=new URL(document.referrer);if(u.origin!==window.location.origin)sessionStorage.setItem('mwp_referrer',u.hostname.slice(0,200));}catch(e){}
    }
  }catch(e){}
})();
const btn=document.querySelector('[data-menu-button]');
const menu=document.querySelector('[data-mobile-menu]');
if(btn&&menu){
  const setMenu=(open)=>{
    menu.classList.toggle('open',open);
    btn.setAttribute('aria-expanded',String(open));
    btn.setAttribute('aria-label',open?'Close menu':'Open menu');
    btn.textContent=open?'×':'☰';
  };
  btn.addEventListener('click',()=>setMenu(!menu.classList.contains('open')));
  menu.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>setMenu(false)));
  document.addEventListener('keydown',e=>{if(e.key==='Escape')setMenu(false)});
  window.addEventListener('resize',()=>{if(window.innerWidth>920)setMenu(false)});
}

document.addEventListener('DOMContentLoaded',()=>{
  const siteLang=(document.documentElement.lang||'en').toLowerCase().startsWith('pt')?'pt':'en';
  const t=(en,pt)=>siteLang==='pt'?pt:en;
  // Keep UTM/service query parameters when switching languages.
  document.querySelectorAll('[data-language-switch]').forEach(a=>{
    if(window.location.search && !a.getAttribute('href').includes('?')) a.setAttribute('href',a.getAttribute('href')+window.location.search);
  });
  // Persistent mobile CTA: appears only after the hero and disappears near the final CTA.
  const sticky=document.querySelector('[data-mobile-sticky]');
  const hero=document.querySelector('[data-mobile-hero]');
  const finalCta=document.querySelector('[data-final-cta]');
  const pricingCta=document.querySelector('.m-price-primary .m-primary-cta');
  if(sticky&&hero){
    let heroVisible=true;
    let finalVisible=false;
    let pricingCtaVisible=false;
    const update=()=>{
      const mobile=window.matchMedia('(max-width:760px)').matches;
      const show=mobile&&!heroVisible&&!finalVisible&&!pricingCtaVisible;
      sticky.classList.toggle('is-visible',show);
      sticky.setAttribute('aria-hidden',String(!show));
    };
    const heroObserver=new IntersectionObserver(entries=>{heroVisible=entries[0].isIntersecting;update();},{threshold:.05});
    heroObserver.observe(hero);
    if(finalCta){
      const finalObserver=new IntersectionObserver(entries=>{finalVisible=entries[0].isIntersecting;update();},{threshold:.08});
      finalObserver.observe(finalCta);
    }
    if(pricingCta){
      const pricingObserver=new IntersectionObserver(entries=>{pricingCtaVisible=entries[0].isIntersecting;update();},{threshold:.5});
      pricingObserver.observe(pricingCta);
    }
    window.addEventListener('resize',update);
    update();
  }

  // Footer links adapt to the separate desktop/mobile section IDs.
  document.querySelectorAll('[data-adaptive-anchor]').forEach(link=>{
    link.addEventListener('click',(e)=>{
      const key=link.dataset.adaptiveAnchor;
      const mobile=window.matchMedia('(max-width:760px)').matches;
      const target=document.getElementById(key+(mobile?'-mobile':'-desktop'));
      if(target){e.preventDefault();target.scrollIntoView({behavior:'smooth',block:'start'});}
    });
  });

  // One-page appointment scheduler: choose an available day, then a real open time.
  const booking=document.getElementById('booking-form');
  if(booking){
    let service='accelerator';
    try{service=new URLSearchParams(window.location.search).get('option')==='single'?'single':'accelerator';}catch(e){}
    const hiddenService=booking.querySelector('[data-service-option]');
    if(hiddenService) hiddenService.value=service;
    const timezone=booking.querySelector('[data-timezone]');
    if(timezone){try{timezone.value=Intl.DateTimeFormat().resolvedOptions().timeZone||'';}catch(e){}}
    booking.querySelectorAll('[data-attribution]').forEach(el=>{
      const key=el.dataset.attribution;
      try{el.value=key==='referrer'?(sessionStorage.getItem('mwp_referrer')||''):(sessionStorage.getItem('mwp_'+key)||'');}catch(e){}
    });

    const dateStrip=booking.querySelector('[data-date-strip]');
    const hourSlots=booking.querySelector('[data-hour-slots]');
    const minuteSlots=booking.querySelector('[data-minute-slots]');
    const selectedDateLabel=booking.querySelector('[data-selected-date-label]');
    const selectedSlot=booking.querySelector('[data-selected-slot]');
    const summary=booking.querySelector('[data-booking-summary]');
    const summaryText=booking.querySelector('[data-booking-summary-text]');
    const submit=booking.querySelector('[data-apply-submit]');
    let availability=[];
    let chosenDate='';
    let chosenHour='';

    const formatDate=(iso)=>{
      const [y,m,d]=iso.split('-').map(Number);
      return new Intl.DateTimeFormat(siteLang==='pt'?'pt-BR':'en-US',{weekday:'long',month:'long',day:'numeric',timeZone:'UTC'}).format(new Date(Date.UTC(y,m-1,d)));
    };
    const parseTimeLabel=(label)=>{
      const raw=String(label||'').trim();
      let m=raw.match(/^(\d{1,2}):(\d{2})\s+(AM|PM)$/i);
      let h,min,ap='';
      if(m){
        h=Number(m[1]);min=Number(m[2]);ap=m[3].toUpperCase();
        if(ap==='PM'&&h!==12)h+=12;if(ap==='AM'&&h===12)h=0;
      }else{
        m=raw.match(/^(\d{1,2}):(\d{2})$/);if(!m)return null;
        h=Number(m[1]);min=Number(m[2]);
      }
      const hourLabel=siteLang==='pt'?`${String(h).padStart(2,'0')}h`:(()=>{let h12=h%12||12;return `${h12} ${h>=12?'PM':'AM'}`;})();
      return {hour24:h,minute:min,hourLabel,minuteLabel:`:${String(min).padStart(2,'0')}`};
    };
    const resetSelection=()=>{
      chosenHour='';selectedSlot.value='';submit.disabled=true;
      if(summary)summary.hidden=true;
      minuteSlots.innerHTML=`<div class="availability-empty">${t('Choose an hour first.','Escolha uma hora primeiro.')}</div>`;
    };
    const renderMinutes=(day,hourLabel)=>{
      chosenHour=hourLabel;
      hourSlots.querySelectorAll('.hour-choice').forEach(b=>b.classList.toggle('selected',b.dataset.hour===hourLabel));
      minuteSlots.innerHTML='';
      selectedSlot.value='';submit.disabled=true;if(summary)summary.hidden=true;
      const group=(day.slots||[]).filter(slot=>parseTimeLabel(slot.label)?.hourLabel===hourLabel);
      if(!group.length){minuteSlots.innerHTML=`<div class="availability-empty">${t('No start times in this hour.','Não há horários de início nesta hora.')}</div>`;return;}
      group.forEach(slot=>{
        const parts=parseTimeLabel(slot.label);if(!parts)return;
        const b=document.createElement('button');b.type='button';b.className=`minute-choice ${slot.status||'available'}`;
        if(slot.status==='available'){
          b.textContent=parts.minuteLabel;b.dataset.slot=slot.start_utc;
          b.addEventListener('click',()=>{
            minuteSlots.querySelectorAll('.minute-choice').forEach(x=>x.classList.remove('selected'));
            b.classList.add('selected');selectedSlot.value=slot.start_utc;submit.disabled=false;
            if(summary&&summaryText){summary.hidden=false;summaryText.textContent=siteLang==='pt'?`${formatDate(day.date)} às ${String(parts.hour24).padStart(2,'0')}:${String(parts.minute).padStart(2,'0')} (horário de Orlando)`:`${formatDate(day.date)} at ${slot.label} ET`;}
          });
        }else{
          b.disabled=true;
          const statusLabel=slot.status==='booked'?t('Booked','Ocupado'):t('Not offered','Indisponível');
          b.innerHTML=`<span>${parts.minuteLabel}</span><small>${statusLabel}</small>`;
          b.setAttribute('aria-label',`${slot.label} ${statusLabel}`);
        }
        minuteSlots.appendChild(b);
      });
    };
    const renderHours=(day)=>{
      chosenDate=day.date;
      dateStrip.querySelectorAll('.date-choice').forEach(b=>b.classList.toggle('selected',b.dataset.date===day.date));
      if(selectedDateLabel)selectedDateLabel.textContent=formatDate(day.date);
      resetSelection();hourSlots.innerHTML='';
      if(!day.slots?.length){
        const msg=day.status==='full'?t('This day is fully booked.','Este dia está totalmente ocupado.'):(day.reason||t('No sessions are offered on this day.','Não há aulas disponíveis neste dia.'));
        hourSlots.innerHTML=`<div class="availability-empty">${msg}</div>`;return;
      }
      const hours=[];const seen=new Set();
      day.slots.forEach(slot=>{const p=parseTimeLabel(slot.label);if(p&&!seen.has(p.hourLabel)){seen.add(p.hourLabel);hours.push(p.hourLabel);}});
      hours.forEach(hourLabel=>{
        const group=day.slots.filter(slot=>parseTimeLabel(slot.label)?.hourLabel===hourLabel);
        const hasOpen=group.some(s=>s.status==='available');
        const hasBooked=group.some(s=>s.status==='booked');
        const b=document.createElement('button');b.type='button';b.dataset.hour=hourLabel;
        b.className=`hour-choice ${hasOpen?'open':hasBooked?'full':'unavailable'}`;
        b.innerHTML=`<span>${hourLabel}</span>${hasOpen?'':'<small>'+(hasBooked?t('Full','Cheio'):t('Not offered','Indisponível'))+'</small>'}`;
        b.addEventListener('click',()=>renderMinutes(day,hourLabel));
        hourSlots.appendChild(b);
      });
    };
    const renderDates=()=>{
      dateStrip.innerHTML='';
      if(!availability.length){
        dateStrip.innerHTML=`<div class="availability-empty">${t('No online times are currently posted. Text Pedro at','Nenhum horário online está disponível agora. Fale com Pedro pelo número')} <a href="sms:+14075802652">(407) 580-2652</a>${t(' and I’ll help you find a time.',' e eu ajudo você a encontrar um horário.')}</div>`;
        hourSlots.innerHTML=`<div class="availability-empty">${t('Available hours will appear here once a day is selected.','Os horários disponíveis aparecerão aqui depois que você escolher um dia.')}</div>`;
        minuteSlots.innerHTML=`<div class="availability-empty">${t('Choose an hour first.','Escolha uma hora primeiro.')}</div>`;
        return;
      }
      availability.forEach(day=>{
        const [y,m,d]=day.date.split('-').map(Number);const dt=new Date(Date.UTC(y,m-1,d));
        const btn=document.createElement('button');btn.type='button';btn.className=`date-choice ${day.status||'open'}`;btn.dataset.date=day.date;
        const statusText=day.status==='full'?t('Full','Cheio'):day.status==='unavailable'?t('Closed','Fechado'):t('Open','Disponível');
        btn.innerHTML=`<span class="dow">${new Intl.DateTimeFormat(siteLang==='pt'?'pt-BR':'en-US',{weekday:'short',timeZone:'UTC'}).format(dt)}</span><span class="day">${d}</span><span class="month">${new Intl.DateTimeFormat(siteLang==='pt'?'pt-BR':'en-US',{month:'short',timeZone:'UTC'}).format(dt)}</span><span class="date-status">${statusText}</span>`;
        if(day.status==='unavailable'){btn.disabled=true;}else{btn.addEventListener('click',()=>renderHours(day));}
        dateStrip.appendChild(btn);
      });
    };
    const previewAvailability=()=>{
      const serviceDuration=service==='single'?60:50;
      const buffer=0;
      const base=new Date();base.setHours(0,0,0,0);
      const dateList=[];let weekdayCount=0,sundayCount=0;let cursor=new Date(base);cursor.setDate(cursor.getDate()+1);
      while((weekdayCount<10||sundayCount<2)&&dateList.length<20){
        const wd=cursor.getDay();
        if(wd===0&&sundayCount<2){dateList.push(new Date(cursor));sundayCount++;}
        else if(wd>=1&&wd<=5&&weekdayCount<10){dateList.push(new Date(cursor));weekdayCount++;}
        cursor.setDate(cursor.getDate()+1);
      }
      const toMinutes=(h,m)=>h*60+m;
      const overlaps=(aStart,aEnd,bStart,bEnd)=>aStart<bEnd+buffer&&aEnd+buffer>bStart;
      const busyFor=(wd)=>({
        1:[[13*60,14*60],[16*60,17*60],[18*60,20*60]],
        2:[[13*60+30,14*60+30],[18*60,20*60]],
        3:[[13*60,14*60],[18*60,20*60]],
        4:[[18*60,20*60]],
        5:[[13*60,20*60]]
      }[wd]||[]);
      return dateList.map(day=>{
        const wd=day.getDay();
        const iso=`${day.getFullYear()}-${String(day.getMonth()+1).padStart(2,'0')}-${String(day.getDate()).padStart(2,'0')}`;
        const window=wd===0?[17*60,22*60]:wd===1||wd===3?[14*60,18*60]:wd===2||wd===4?[13*60,18*60]:null;
        const display=wd===0?[17*60,21*60]:[13*60,19*60+45];
        const busy=busyFor(wd);const slots=[];
        for(let t=display[0];t<=display[1];t+=15){
          const h=Math.floor(t/60),m=t%60;const d=new Date(day);d.setHours(h,m,0,0);
          const label=new Intl.DateTimeFormat(siteLang==='pt'?'pt-BR':'en-US',{hour:'numeric',minute:'2-digit'}).format(d);
          const candidateEnd=t+serviceDuration;
          const booked=busy.some(([bs,be])=>overlaps(t,candidateEnd,bs,be));
          const inside=window&&t>=window[0]&&candidateEnd<=window[1];
          slots.push({start_utc:inside&&!booked?d.toISOString():undefined,label,status:booked?'booked':inside?'available':'unavailable'});
        }
        const hasOpen=slots.some(s=>s.status==='available'),hasBooked=slots.some(s=>s.status==='booked');
        return {date:iso,status:hasOpen?'open':hasBooked?'full':'unavailable',slots};
      });
    };
    const loadAvailability=async()=>{
      if(window.location.protocol==='file:'){availability=previewAvailability();renderDates();return;}
      try{
        const r=await fetch(`/api/availability?service=${encodeURIComponent(service)}&days=21`,{headers:{'Accept':'application/json'}});
        if(!r.ok)throw new Error('availability');
        const data=await r.json();availability=data.dates||[];renderDates();
      }catch(e){
        dateStrip.innerHTML=`<div class="availability-error">${t('I couldn’t load the schedule right now. Please text Pedro at','Não foi possível carregar a agenda agora. Fale com Pedro pelo número')} <a href="sms:+14075802652">(407) 580-2652</a>.</div>`;
        hourSlots.innerHTML='';minuteSlots.innerHTML='';
      }
    };
    loadAvailability();

    // Static-file demo still behaves like a working prototype.
    if(window.location.protocol==='file:'){
      booking.addEventListener('submit',(e)=>{
        e.preventDefault();if(!booking.reportValidity()||!selectedSlot.value)return;
        const data=Object.fromEntries(new FormData(booking).entries());
        localStorage.setItem('mwp_last_booking',JSON.stringify({...data,created_at:new Date().toISOString()}));
        window.location.href=data.service_option==='single'?'success.html?option=single':'success.html';
      });
    }
  }

  document.querySelectorAll('[data-logout]').forEach(el=>el.addEventListener('click',()=>localStorage.removeItem('mwp_demo_auth')));

  const reschedule=document.getElementById('reschedule-form');
  if(reschedule&&window.location.protocol==='file:'){
    reschedule.addEventListener('submit',(e)=>{
      e.preventDefault();
      if(!reschedule.reportValidity())return;
      const data=Object.fromEntries(new FormData(reschedule).entries());
      localStorage.setItem('mwp_reschedule_request',JSON.stringify({...data,created_at:new Date().toISOString()}));
      const msg=document.getElementById('reschedule-message');
      msg.textContent='Reschedule request saved in this local preview.';
      msg.style.display='block';
      reschedule.reset();
      msg.scrollIntoView({behavior:'smooth',block:'center'});
    });
  }
});

// Product-aware intake: the Accelerator gets the free first session; single sessions are $70.
document.addEventListener('DOMContentLoaded',()=>{
  const form=document.getElementById('booking-form');
  if(!form) return;
  let option='accelerator';
  try{option=new URLSearchParams(window.location.search).get('option')==='single'?'single':'accelerator';}catch(e){}
  const hidden=form.querySelector('[data-service-option]');
  if(hidden) hidden.value=option;
  if(option==='single'){
    const pt=(document.documentElement.lang||'').toLowerCase().startsWith('pt');
    document.title=pt?'Agende uma Aula Avulsa de Matemática do SAT por US$ 70 | Math with Pedro':'Book a $70 Single SAT Math Session | Math with Pedro';
    const set=(sel,en,br)=>{const el=document.querySelector(sel);if(el)el.textContent=pt?br:en;};
    set('[data-apply-kicker]','INDIVIDUAL SAT MATH SESSION · $70','AULA AVULSA DE MATEMÁTICA DO SAT · US$ 70');
    set('[data-apply-title]','Book a private 60-minute SAT Math session.','Agende uma aula particular de 60 minutos de Matemática do SAT.');
    set('[data-apply-lead]','Best for one-off help with a specific SAT Math topic or an occasional check-in. Choose an available day and time and reserve the session instantly.','Ideal para ajuda pontual em um tópico específico ou uma revisão ocasional. Escolha um dia e horário disponível e reserve a aula.');
    const p1=document.querySelector('[data-apply-proof-1]'); if(p1){p1.querySelector('b').textContent='60 min';p1.querySelector('span').textContent=pt?'Aula individual':'Private 1-on-1 session';}
    const p2=document.querySelector('[data-apply-proof-2]'); if(p2){p2.querySelector('b').textContent=pt?'US$ 70':'$70';p2.querySelector('span').textContent=pt?'Aula avulsa':'Single session';}
    const p3=document.querySelector('[data-apply-proof-3]'); if(p3){p3.querySelector('b').textContent='Online';p3.querySelector('span').textContent=pt?'Inglês ou português':'English or Portuguese';}
    set('[data-apply-submit]','Book My $70 Session','Agendar Minha Aula de US$ 70');
    set('[data-apply-legal]','$70 · 60 minutes · 1-on-1. Your selected time is reserved when you submit; payment details will be sent by email. If the student is under 18, a parent or guardian should submit this form.','US$ 70 · 60 minutos · individual. O horário escolhido fica reservado ao enviar o formulário; os detalhes de pagamento serão enviados por e-mail. Se o aluno for menor de 18 anos, o formulário deve ser enviado por um pai, mãe ou responsável.');
  }
});

// Tailor the confirmation page to the service requested.
document.addEventListener('DOMContentLoaded',()=>{
  if(!document.querySelector('.success-card')) return;
  let single=false;try{single=new URLSearchParams(window.location.search).get('option')==='single';}catch(e){}
  if(!single)return;
  const pt=(document.documentElement.lang||'').toLowerCase().startsWith('pt');
  const h=document.querySelector('.success-card h1');
  const p=document.querySelector('.success-card p');
  if(h)h.textContent=pt?'Sua aula avulsa de Matemática do SAT está agendada.':'Your single SAT Math session is booked.';
  if(p)p.textContent=pt?'O horário escolhido está reservado para uma aula particular de 60 minutos de Matemática do SAT. Confira seu e-mail para os detalhes da aula e do pagamento.':'Your selected time is reserved for a private 60-minute SAT Math session. Check your email for the appointment and payment details.';
});
