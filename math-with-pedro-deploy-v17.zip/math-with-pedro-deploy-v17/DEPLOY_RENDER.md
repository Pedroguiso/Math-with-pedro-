# Fast launch: Render + custom domain

## 1. Put this folder in a private GitHub repository
`render.yaml` must be in the repository root beside `app.py`.

Do not upload a `.env` containing passwords.

## 2. Create a Render Blueprint
Create a **Blueprint** from the repository. The included `render.yaml` creates:
- one paid Python web service;
- one 1 GB persistent disk at `/var/data`;
- automatic HTTPS;
- a generated `SECRET_KEY`.

## 3. Enter the private environment values
- `ADMIN_PASSWORD`
- `LEAD_NOTIFY_TO`
- `PUBLIC_CONTACT_EMAIL`
- `SMTP_HOST`
- `SMTP_USER`
- `SMTP_PASSWORD`
- `SMTP_FROM`

For Google Workspace/Gmail, `SMTP_HOST=smtp.gmail.com` and use an app password rather than the normal account password.

The code defaults to:
- public phone: `(407) 580-2652`
- booking timezone: `America/New_York`
- minimum booking notice: 2 hours
- buffer between bookings: 0 minutes (back-to-back sessions allowed)

These can be overridden with `PUBLIC_PHONE`, `BUSINESS_TZ`, `BOOKING_MIN_NOTICE_HOURS`, and `BOOKING_BUFFER_MINUTES` if needed.

## 4. Verify your booking calendar BEFORE sharing the link
V9 ships with Pedro's current recurring schedule already seeded: Monday/Wednesday afternoons, Tuesday/Thursday afternoons, Sunday 5–9 PM start times, plus the existing-client blocks shown as booked.

After the first deploy:

1. open `/admin`;
2. log in;
3. review **Booking availability**;
4. block any one-off dates when you are unavailable;
5. open `/apply` and verify the public calendar.

Same-day bookings are not shown publicly. The scheduler starts with tomorrow and shows the next two workweeks plus two Sundays.

## 5. Test the temporary Render URL
Verify:
1. homepage loads;
2. `/healthz` returns `{"ok": true}`;
3. `/admin` accepts your password;
4. **Send test email** works;
5. `/apply` displays only the availability you entered;
6. submit a test booking with your own email/phone;
7. confirm the slot disappears from public availability;
8. confirm the booking appears in admin with the phone number;
9. confirm both notification emails arrive.

## 6. Connect the custom domain
In Render: **Service → Settings → Custom Domains → Add Custom Domain**.

Add the DNS records Render supplies. Render manages HTTPS automatically.

## 7. Final live-domain test
On your actual phone:

**Home → Start Free Session → enter contact info → choose day → choose time → Book → confirmation → admin/email**

Only after that should you begin posting the link widely.
