from __future__ import annotations

import csv
import hashlib
import hmac
import html
import io
import json
import logging
import mimetypes
import os
import re
import secrets
import smtplib
import sqlite3
try:
    import psycopg
    from psycopg.rows import dict_row
except ImportError:
    psycopg = None
    dict_row = None
import sys
from datetime import datetime, timedelta, timezone
from zoneinfo import ZoneInfo
from email.message import EmailMessage
from http import cookies
from pathlib import Path
from urllib.parse import parse_qs, quote, unquote, urlencode
from wsgiref.simple_server import make_server

ROOT = Path(__file__).resolve().parent
STATIC_DIR = ROOT / "static"
DATA_DIR = Path(os.environ.get("DATA_DIR", str(ROOT / "data"))).expanduser().resolve()
DB_PATH = DATA_DIR / "site.db"
DATABASE_URL = os.environ.get("DATABASE_URL", "").strip()
PORT = int(os.environ.get("PORT", "8000"))
PRODUCTION = os.environ.get("PRODUCTION", "0").lower() in {"1", "true", "yes"}
TRUST_PROXY = os.environ.get("TRUST_PROXY", "0").lower() in {"1", "true", "yes"}
SECRET_KEY = os.environ.get("SECRET_KEY", "")
ADMIN_PASSWORD = os.environ.get("ADMIN_PASSWORD", "")
PUBLIC_CONTACT_EMAIL = os.environ.get("PUBLIC_CONTACT_EMAIL", "")
LEAD_NOTIFY_TO = os.environ.get("LEAD_NOTIFY_TO", "")
PUBLIC_PHONE = os.environ.get("PUBLIC_PHONE", "407-580-2652")
BUSINESS_TZ_NAME = os.environ.get("BUSINESS_TZ", "America/New_York")
BUSINESS_TZ = ZoneInfo(BUSINESS_TZ_NAME)
BOOKING_MIN_NOTICE_HOURS = int(os.environ.get("BOOKING_MIN_NOTICE_HOURS", "2"))
BOOKING_BUFFER_MINUTES = int(os.environ.get("BOOKING_BUFFER_MINUTES", "0"))
SLOT_STEP_MINUTES = int(os.environ.get("SLOT_STEP_MINUTES", "15"))
SERVICE_DURATION_MINUTES = {"accelerator": 50, "single": 60}

logging.basicConfig(
    level=os.environ.get("LOG_LEVEL", "INFO"),
    format="%(asctime)s %(levelname)s %(message)s",
)
log = logging.getLogger("math-with-pedro")

if not SECRET_KEY:
    # Safe for local development only. Production explicitly refuses to start below.
    SECRET_KEY = secrets.token_hex(32)
    log.warning("SECRET_KEY not set; using an ephemeral development key.")

if PRODUCTION:
    missing = []
    if not os.environ.get("SECRET_KEY"):
        missing.append("SECRET_KEY")
    if not ADMIN_PASSWORD:
        missing.append("ADMIN_PASSWORD")
    if not DATABASE_URL and not os.environ.get("DATA_DIR"):
        missing.append("DATABASE_URL or DATA_DIR (persistent database storage)")
    if missing:
        raise RuntimeError("Production configuration missing: " + ", ".join(missing))
    if not os.environ.get("SMTP_HOST") or not (os.environ.get("SMTP_FROM") or os.environ.get("SMTP_USER")):
        log.warning("SMTP is not configured; bookings will still be stored, but confirmation/notification emails will not be sent.")

EMAIL_RE = re.compile(r"^[^\s@]+@[^\s@]+\.[^\s@]+$")
ALLOWED_STATUSES = {"new", "contacted", "scheduled", "converted", "closed"}


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


def iso_now() -> str:
    return utcnow().isoformat(timespec="seconds")



def normalize_phone(value: str) -> str:
    raw = (value or "").strip()
    digits = re.sub(r"\D", "", raw)
    if len(digits) == 11 and digits.startswith("1"):
        digits = digits[1:]
    return digits


def display_phone(value: str) -> str:
    digits = normalize_phone(value)
    if len(digits) == 10:
        return f"({digits[:3]}) {digits[3:6]}-{digits[6:]}"
    return value or ""


def service_duration(service: str) -> int:
    return SERVICE_DURATION_MINUTES.get("single" if service == "single" else "accelerator", 50)


def business_datetime_label(iso_utc: str, lang: str = "en") -> str:
    try:
        dt = datetime.fromisoformat((iso_utc or "").replace("Z", "+00:00"))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        local = dt.astimezone(BUSINESS_TZ)
        if lang == "pt":
            weekdays = ["segunda-feira", "terça-feira", "quarta-feira", "quinta-feira", "sexta-feira", "sábado", "domingo"]
            months = ["janeiro", "fevereiro", "março", "abril", "maio", "junho", "julho", "agosto", "setembro", "outubro", "novembro", "dezembro"]
            return f"{weekdays[local.weekday()]}, {local.day} de {months[local.month-1]}, às {local.strftime('%H:%M')} (horário de Orlando)"
        hour = local.strftime("%I").lstrip("0") or "0"
        return f"{local.strftime('%A, %B')} {local.day} at {hour}:{local.strftime('%M %p')} ET"
    except Exception:
        return iso_utc or ""


def _parse_time(value: str):
    try:
        return datetime.strptime(value, "%H:%M").time()
    except Exception:
        return None


def _recurring_external_busy(day):
    """Recurring times already occupied by Pedro's existing students.

    These are genuine off-site/existing-client commitments, not synthetic scarcity.
    Returned datetimes are in the business timezone.
    """
    blocks_by_weekday = {
        0: [("13:00", "14:00"), ("16:00", "17:00"), ("18:00", "20:00")],  # Monday
        1: [("13:30", "14:30"), ("18:00", "20:00")],                         # Tuesday
        2: [("13:00", "14:00"), ("18:00", "20:00")],                         # Wednesday
        3: [("18:00", "20:00")],                                                   # Thursday
        4: [("13:00", "20:00")],                                                   # Friday full
    }
    out = []
    for start_s, end_s in blocks_by_weekday.get(day.weekday(), []):
        st = _parse_time(start_s); en = _parse_time(end_s)
        if st and en:
            out.append((datetime.combine(day, st, BUSINESS_TZ), datetime.combine(day, en, BUSINESS_TZ)))
    return out


def _actual_appointments_for_day(con: sqlite3.Connection, day):
    rows = con.execute(
        "SELECT start_utc,end_utc FROM appointments WHERE status='booked' AND start_utc>=? AND start_utc<? ORDER BY start_utc",
        (
            datetime.combine(day, datetime.min.time(), BUSINESS_TZ).astimezone(timezone.utc).isoformat(timespec="seconds"),
            datetime.combine(day + timedelta(days=1), datetime.min.time(), BUSINESS_TZ).astimezone(timezone.utc).isoformat(timespec="seconds"),
        ),
    ).fetchall()
    out = []
    for a in rows:
        try:
            st = datetime.fromisoformat(a["start_utc"].replace("Z", "+00:00")).astimezone(BUSINESS_TZ)
            en = datetime.fromisoformat(a["end_utc"].replace("Z", "+00:00")).astimezone(BUSINESS_TZ)
            out.append((st, en))
        except Exception:
            pass
    return out


def _busy_intervals_for_day(con: sqlite3.Connection, day):
    return _actual_appointments_for_day(con, day) + _recurring_external_busy(day)


def _candidate_conflicts(start_local: datetime, duration_minutes: int, busy_intervals) -> bool:
    end_local = start_local + timedelta(minutes=duration_minutes)
    # Protect a small buffer after the proposed session and after an existing booking.
    candidate_end = end_local + timedelta(minutes=BOOKING_BUFFER_MINUTES)
    for busy_start, busy_end in busy_intervals:
        busy_end_buffered = busy_end + timedelta(minutes=BOOKING_BUFFER_MINUTES)
        if start_local < busy_end_buffered and candidate_end > busy_start:
            return True
    return False


def available_slots_for_date(date_str: str, service: str, con: sqlite3.Connection | None = None) -> list[dict[str, str]]:
    own = con is None
    if own:
        con = db_conn()
    try:
        try:
            day = datetime.strptime(date_str, "%Y-%m-%d").date()
        except ValueError:
            return []
        today = datetime.now(BUSINESS_TZ).date()
        # Public scheduling starts tomorrow. This avoids awkward same-day bookings and
        # keeps the calendar feeling intentional even when a visitor arrives late in the day.
        if day <= today or day > today + timedelta(days=60):
            return []
        if con.execute("SELECT 1 FROM blocked_dates WHERE date=?", (date_str,)).fetchone():
            return []
        windows = con.execute(
            "SELECT start_time,end_time FROM weekly_availability WHERE weekday=? ORDER BY start_time",
            (day.weekday(),),
        ).fetchall()
        if not windows:
            return []

        busy = _busy_intervals_for_day(con, day)
        duration_minutes = service_duration(service)
        duration = timedelta(minutes=duration_minutes)
        step = timedelta(minutes=15)
        min_start = utcnow() + timedelta(hours=max(0, BOOKING_MIN_NOTICE_HOURS))
        slots = []
        seen = set()
        for w in windows:
            st_t = _parse_time(w["start_time"]); en_t = _parse_time(w["end_time"])
            if not st_t or not en_t:
                continue
            cur_local = datetime.combine(day, st_t, BUSINESS_TZ)
            window_end_local = datetime.combine(day, en_t, BUSINESS_TZ)
            if window_end_local <= cur_local:
                continue
            while cur_local + duration <= window_end_local:
                start_utc = cur_local.astimezone(timezone.utc)
                end_utc = (cur_local + duration).astimezone(timezone.utc)
                key = start_utc.isoformat(timespec="seconds")
                if start_utc >= min_start and key not in seen and not _candidate_conflicts(cur_local, duration_minutes, busy):
                    hour = cur_local.strftime("%I").lstrip("0") or "0"
                    slots.append({
                        "start_utc": key,
                        "end_utc": end_utc.isoformat(timespec="seconds"),
                        "label": f"{hour}:{cur_local.strftime('%M %p')}",
                    })
                    seen.add(key)
                cur_local += step
        return slots
    finally:
        if own:
            con.close()


def _public_calendar_dates(today):
    """Next two workweeks plus two Sundays, never including today or Saturdays."""
    out = []
    weekday_count = 0
    sunday_count = 0
    d = today + timedelta(days=1)
    while (weekday_count < 10 or sunday_count < 2) and d <= today + timedelta(days=28):
        wd = d.weekday()
        if wd == 6 and sunday_count < 2:
            out.append(d); sunday_count += 1
        elif wd <= 4 and weekday_count < 10:
            out.append(d); weekday_count += 1
        d += timedelta(days=1)
    return sorted(out)


def _display_range_for_day(day):
    """Visible start-time range used by the compact hour/minute picker."""
    wd = day.weekday()
    if wd == 6:  # Sunday: tutoring window is 5 PM–9 PM.
        return (17, 0), (21, 0)  # start times from 5:00 PM through 9:00 PM
    if wd == 4:  # Friday is occupied by existing clients.
        return (13, 0), (19, 45)
    if wd in (0, 2):
        return (13, 0), (19, 45)
    if wd in (1, 3):
        return (13, 0), (19, 45)
    return None


def availability_payload(service: str, days: int = 14) -> dict:
    """Return a compact two-week calendar plus Sundays.

    Slots use 15-minute start increments. Existing site appointments and Pedro's
    pre-existing tutoring commitments are represented as booked. Same-day booking
    is intentionally omitted from the public calendar.
    """
    service = "single" if service == "single" else "accelerator"
    today = datetime.now(BUSINESS_TZ).date()
    con = db_conn()
    try:
        out = []
        duration_minutes = service_duration(service)
        for d in _public_calendar_dates(today):
            ds = d.isoformat()
            blocked = con.execute("SELECT reason FROM blocked_dates WHERE date=?", (ds,)).fetchone()
            windows = con.execute(
                "SELECT start_time,end_time FROM weekly_availability WHERE weekday=? ORDER BY start_time",
                (d.weekday(),),
            ).fetchall()
            busy = _busy_intervals_for_day(con, d)

            if blocked:
                out.append({
                    "date": ds,
                    "status": "unavailable",
                    "reason": (blocked["reason"] if blocked["reason"] else "Not available"),
                    "slots": [],
                })
                continue

            display_range = _display_range_for_day(d)
            if not display_range:
                continue

            open_slots = {x["start_utc"]: x for x in available_slots_for_date(ds, service, con)}
            (sh, sm), (eh, em) = display_range
            cur = datetime.combine(d, datetime.min.time(), BUSINESS_TZ).replace(hour=sh, minute=sm)
            last = datetime.combine(d, datetime.min.time(), BUSINESS_TZ).replace(hour=eh, minute=em)
            display_slots = []
            while cur <= last:
                start_utc = cur.astimezone(timezone.utc)
                key = start_utc.isoformat(timespec="seconds")
                label = cur.strftime("%-I:%M %p")
                if key in open_slots:
                    display_slots.append({"label": label, "status": "available", "start_utc": key})
                elif _candidate_conflicts(cur, duration_minutes, busy):
                    # The start cannot be offered because it overlaps a real appointment or
                    # an existing off-site tutoring commitment.
                    display_slots.append({"label": label, "status": "booked"})
                else:
                    display_slots.append({"label": label, "status": "unavailable"})
                cur += timedelta(minutes=15)

            has_open = any(x.get("status") == "available" for x in display_slots)
            has_booked = any(x.get("status") == "booked" for x in display_slots)
            day_status = "open" if has_open else ("full" if has_booked else "unavailable")
            reason = "Fully booked" if day_status == "full" else ""
            out.append({"date": ds, "status": day_status, "reason": reason, "slots": display_slots})

        return {
            "timezone": BUSINESS_TZ_NAME,
            "timezone_label": "Eastern Time (Orlando)",
            "service": service,
            "duration_minutes": service_duration(service),
            "dates": out,
        }
    finally:
        con.close()

def _db_sql(sql: str) -> str:
    if not DATABASE_URL:
        return sql
    if sql.strip().upper() == "BEGIN IMMEDIATE":
        return "BEGIN"
    return sql.replace("?", "%s")


class DBConnection:
    def __init__(self, raw, postgres=False):
        self.raw = raw
        self.postgres = postgres
    def execute(self, sql, params=()):
        return self.raw.execute(_db_sql(sql), params)
    def executemany(self, sql, params_seq):
        return self.raw.executemany(_db_sql(sql), params_seq)
    def executescript(self, script):
        if not self.postgres:
            return self.raw.executescript(script)
        script = script.replace("INTEGER PRIMARY KEY AUTOINCREMENT", "SERIAL PRIMARY KEY")
        for statement in script.split(";"):
            statement = statement.strip()
            if statement:
                self.raw.execute(statement)
    def commit(self): return self.raw.commit()
    def rollback(self): return self.raw.rollback()
    def close(self): return self.raw.close()


def db_conn():
    if DATABASE_URL:
        if psycopg is None:
            raise RuntimeError("DATABASE_URL is set but psycopg is not installed")
        return DBConnection(psycopg.connect(DATABASE_URL, row_factory=dict_row), postgres=True)
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(DB_PATH, timeout=10)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys=ON")
    con.execute("PRAGMA journal_mode=WAL")
    con.execute("PRAGMA busy_timeout=5000")
    return DBConnection(con, postgres=False)


def init_db() -> None:
    if not DATABASE_URL:
        DATA_DIR.mkdir(parents=True, exist_ok=True)
    con = db_conn()
    con.executescript(
        """
        CREATE TABLE IF NOT EXISTS leads(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          created_at TEXT NOT NULL,
          parent_name TEXT NOT NULL,
          student_name TEXT NOT NULL,
          email TEXT NOT NULL,
          phone TEXT,
          current_score TEXT,
          target_score TEXT,
          preferred_session TEXT NOT NULL,
          alternate_session TEXT,
          timezone TEXT,
          utm_source TEXT,
          utm_medium TEXT,
          utm_campaign TEXT,
          utm_content TEXT,
          referrer TEXT,
          service_option TEXT NOT NULL DEFAULT 'accelerator',
          language TEXT NOT NULL DEFAULT 'en',
          status TEXT NOT NULL DEFAULT 'new',
          notification_status TEXT,
          confirmation_status TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_leads_created_at ON leads(created_at DESC);
        CREATE INDEX IF NOT EXISTS idx_leads_email ON leads(email);

        CREATE TABLE IF NOT EXISTS lead_attempts(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          ip_hash TEXT NOT NULL,
          created_at TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_attempts_ip_time ON lead_attempts(ip_hash, created_at);

        CREATE TABLE IF NOT EXISTS auth_attempts(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          scope TEXT NOT NULL,
          ip_hash TEXT NOT NULL,
          created_at TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_auth_scope_ip_time ON auth_attempts(scope, ip_hash, created_at);

        CREATE TABLE IF NOT EXISTS users(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          name TEXT NOT NULL,
          email TEXT UNIQUE NOT NULL,
          salt TEXT NOT NULL,
          password_hash TEXT NOT NULL,
          role TEXT NOT NULL DEFAULT 'student',
          current_score INTEGER,
          target_score INTEGER,
          sat_date TEXT,
          next_session TEXT,
          current_focus TEXT
        );
        CREATE TABLE IF NOT EXISTS student_sessions(
          token TEXT PRIMARY KEY,
          user_id INTEGER NOT NULL,
          csrf_token TEXT NOT NULL,
          expires_at TEXT NOT NULL,
          FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS admin_sessions(
          token TEXT PRIMARY KEY,
          csrf_token TEXT NOT NULL,
          expires_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS assignments(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          user_id INTEGER NOT NULL,
          title TEXT NOT NULL,
          detail TEXT,
          due_date TEXT,
          complete INTEGER NOT NULL DEFAULT 0,
          FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS score_history(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          user_id INTEGER NOT NULL,
          label TEXT NOT NULL,
          score INTEGER NOT NULL,
          recorded_at TEXT NOT NULL,
          FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS session_notes(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          user_id INTEGER NOT NULL,
          session_date TEXT NOT NULL,
          topic TEXT NOT NULL,
          notes TEXT NOT NULL,
          FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
        );

        CREATE TABLE IF NOT EXISTS weekly_availability(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          weekday INTEGER NOT NULL CHECK(weekday BETWEEN 0 AND 6),
          start_time TEXT NOT NULL,
          end_time TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_weekly_availability_day ON weekly_availability(weekday,start_time);

        CREATE TABLE IF NOT EXISTS blocked_dates(
          date TEXT PRIMARY KEY,
          reason TEXT
        );

        CREATE TABLE IF NOT EXISTS appointments(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          lead_id INTEGER UNIQUE NOT NULL,
          start_utc TEXT UNIQUE NOT NULL,
          end_utc TEXT NOT NULL,
          service_option TEXT NOT NULL,
          created_at TEXT NOT NULL,
          status TEXT NOT NULL DEFAULT 'booked',
          FOREIGN KEY(lead_id) REFERENCES leads(id) ON DELETE CASCADE
        );
        CREATE INDEX IF NOT EXISTS idx_appointments_start ON appointments(start_utc);

        CREATE TABLE IF NOT EXISTS reschedule_requests(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          user_id INTEGER NOT NULL,
          created_at TEXT NOT NULL,
          requested_time TEXT NOT NULL,
          note TEXT,
          FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
        );
        """
    )
    # Lightweight schema migration for product-aware lead tracking.
    if DATABASE_URL:
        lead_cols = {row["column_name"] for row in con.execute(
            "SELECT column_name FROM information_schema.columns WHERE table_schema='public' AND table_name='leads'"
        ).fetchall()}
    else:
        lead_cols = {row["name"] for row in con.execute("PRAGMA table_info(leads)").fetchall()}
    if "service_option" not in lead_cols:
        con.execute("ALTER TABLE leads ADD COLUMN service_option TEXT NOT NULL DEFAULT 'accelerator'")
    if "phone" not in lead_cols:
        con.execute("ALTER TABLE leads ADD COLUMN phone TEXT")
    if "language" not in lead_cols:
        con.execute("ALTER TABLE leads ADD COLUMN language TEXT NOT NULL DEFAULT 'en'")

    # Seed Pedro's default weekly tutoring schedule only for a fresh database.
    if con.execute("SELECT COUNT(*) AS n FROM weekly_availability").fetchone()["n"] == 0:
        con.executemany(
            "INSERT INTO weekly_availability(weekday,start_time,end_time) VALUES(?,?,?)",
            [
                (0, "14:00", "18:00"),  # Monday: 2–6 PM tutoring window
                (1, "13:00", "18:00"),  # Tuesday: 1–6 PM tutoring window
                (2, "14:00", "18:00"),  # Wednesday: 2–6 PM tutoring window
                (3, "13:00", "18:00"),  # Thursday: 1–6 PM tutoring window
                (6, "17:00", "22:00"),  # Sunday: start times offered from 5–9 PM
            ],
        )

    # Add Sunday hours to databases created by an earlier release.
    if not con.execute("SELECT 1 FROM weekly_availability WHERE weekday=6").fetchone():
        con.execute("INSERT INTO weekly_availability(weekday,start_time,end_time) VALUES(?,?,?)", (6, "17:00", "22:00"))
    # Migrate older default schedule values without touching custom hours.
    con.execute("UPDATE weekly_availability SET end_time='18:00' WHERE weekday IN (0,1,2,3) AND end_time='18:30'")
    con.execute("UPDATE weekly_availability SET end_time='22:00' WHERE weekday=6 AND start_time='17:00' AND end_time='21:00'")

    # Remove the old demo account if it exists from a previous local database.
    demo = con.execute("SELECT id FROM users WHERE email=?", ("student@example.com",)).fetchone()
    if demo:
        con.execute("DELETE FROM users WHERE id=?", (demo["id"],))
    # Expire old server-side sessions.
    now = iso_now()
    con.execute("DELETE FROM student_sessions WHERE expires_at <= ?", (now,))
    con.execute("DELETE FROM admin_sessions WHERE expires_at <= ?", (now,))
    con.commit()
    con.close()


def hash_password(password: str, salt: bytes | None = None) -> tuple[str, str]:
    salt = salt or secrets.token_bytes(16)
    dk = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, 240_000)
    return salt.hex(), dk.hex()


def verify_password(password: str, salt_hex: str, hash_hex: str) -> bool:
    salt = bytes.fromhex(salt_hex)
    _, candidate = hash_password(password, salt)
    return hmac.compare_digest(candidate, hash_hex)


def esc(value) -> str:
    return html.escape(str(value or ""), quote=True)


def clamp(value: str, max_len: int) -> str:
    return (value or "").strip()[:max_len]


def parse_cookies(environ) -> dict[str, str]:
    jar = cookies.SimpleCookie()
    try:
        jar.load(environ.get("HTTP_COOKIE", ""))
    except cookies.CookieError:
        return {}
    return {k: morsel.value for k, morsel in jar.items()}


def cookie_header(name: str, value: str, max_age: int, *, clear: bool = False) -> str:
    parts = [f"{name}={value}", "Path=/", "HttpOnly", "SameSite=Lax"]
    if PRODUCTION:
        parts.append("Secure")
    if clear:
        parts.extend(["Max-Age=0", "Expires=Thu, 01 Jan 1970 00:00:00 GMT"])
    else:
        parts.append(f"Max-Age={max_age}")
    return "; ".join(parts)


def client_ip(environ) -> str:
    if TRUST_PROXY:
        forwarded = environ.get("HTTP_X_FORWARDED_FOR", "")
        if forwarded:
            return forwarded.split(",", 1)[0].strip()
    return environ.get("REMOTE_ADDR", "unknown")


def ip_hash(ip: str) -> str:
    return hmac.new(SECRET_KEY.encode(), ip.encode(), hashlib.sha256).hexdigest()


def read_form(environ) -> dict[str, str]:
    try:
        length = min(int(environ.get("CONTENT_LENGTH") or 0), 64_000)
    except ValueError:
        length = 0
    raw = environ["wsgi.input"].read(length).decode("utf-8", errors="replace")
    parsed = parse_qs(raw, keep_blank_values=True)
    return {k: v[0] if v else "" for k, v in parsed.items()}


def query_params(environ) -> dict[str, str]:
    parsed = parse_qs(environ.get("QUERY_STRING", ""), keep_blank_values=True)
    return {k: v[0] if v else "" for k, v in parsed.items()}


def security_headers(environ, *, sensitive: bool = False) -> list[tuple[str, str]]:
    headers = [
        ("X-Content-Type-Options", "nosniff"),
        ("X-Frame-Options", "DENY"),
        ("Referrer-Policy", "strict-origin-when-cross-origin"),
        ("Permissions-Policy", "camera=(), microphone=(), geolocation=()"),
        ("Content-Security-Policy", "default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; script-src 'self'; connect-src 'self'; form-action 'self'; frame-ancestors 'none'; base-uri 'self'"),
    ]
    scheme = environ.get("wsgi.url_scheme", "http")
    if TRUST_PROXY and environ.get("HTTP_X_FORWARDED_PROTO"):
        scheme = environ.get("HTTP_X_FORWARDED_PROTO", "").split(",", 1)[0].strip()
    if scheme == "https":
        headers.append(("Strict-Transport-Security", "max-age=31536000; includeSubDomains"))
    if sensitive:
        headers.append(("Cache-Control", "no-store"))
    return headers


def respond(start_response, environ, body: str | bytes, status: str = "200 OK", content_type: str = "text/html; charset=utf-8", extra_headers=None, sensitive=False):
    data = body.encode("utf-8") if isinstance(body, str) else body
    headers = [("Content-Type", content_type), ("Content-Length", str(len(data)))]
    headers.extend(security_headers(environ, sensitive=sensitive))
    if extra_headers:
        headers.extend(extra_headers)
    start_response(status, headers)
    return [data]


def redirect(start_response, environ, location: str, extra_headers=None):
    headers = [("Location", location), ("Content-Length", "0")]
    headers.extend(security_headers(environ, sensitive=True))
    if extra_headers:
        headers.extend(extra_headers)
    start_response("303 See Other", headers)
    return [b""]


def static_file(start_response, environ, rel_path: str):
    fp = (ROOT / rel_path).resolve()
    if not str(fp).startswith(str(ROOT.resolve())) or not fp.is_file():
        return respond(start_response, environ, "Not found", "404 Not Found", "text/plain; charset=utf-8")
    data = fp.read_bytes()
    mime = mimetypes.guess_type(fp.name)[0] or "application/octet-stream"
    extra = [("Cache-Control", "public, max-age=86400")] if rel_path.startswith("static/") else [("Cache-Control", "no-cache")]
    return respond(start_response, environ, data, content_type=mime, extra_headers=extra)


def smtp_configured() -> bool:
    return bool(os.environ.get("SMTP_HOST") and (os.environ.get("SMTP_FROM") or os.environ.get("SMTP_USER")))


def send_email(to_address: str, subject: str, text: str, *, reply_to: str | None = None) -> None:
    if not smtp_configured() or not to_address:
        raise RuntimeError("SMTP is not configured")
    host = os.environ["SMTP_HOST"]
    port = int(os.environ.get("SMTP_PORT", "587"))
    username = os.environ.get("SMTP_USER", "")
    password = os.environ.get("SMTP_PASSWORD", "")
    sender = os.environ.get("SMTP_FROM") or username
    use_ssl = os.environ.get("SMTP_USE_SSL", "0").lower() in {"1", "true", "yes"} or port == 465
    use_starttls = os.environ.get("SMTP_STARTTLS", "1").lower() in {"1", "true", "yes"}

    msg = EmailMessage()
    msg["From"] = sender
    msg["To"] = to_address
    msg["Subject"] = subject
    if reply_to:
        msg["Reply-To"] = reply_to
    msg.set_content(text)

    smtp_cls = smtplib.SMTP_SSL if use_ssl else smtplib.SMTP
    with smtp_cls(host, port, timeout=10) as smtp:
        if not use_ssl and use_starttls:
            smtp.starttls()
        if username:
            smtp.login(username, password)
        smtp.send_message(msg)


def lead_owner_email(lead: sqlite3.Row | dict) -> tuple[str, str]:
    def g(key):
        try:
            return lead[key]
        except Exception:
            return ""
    source = " / ".join(x for x in [g("utm_source"), g("utm_campaign")] if x) or g("referrer") or "Direct / unknown"
    session_label = business_datetime_label(g("preferred_session"))
    subject = f"New SAT Math booking — {g('student_name')} — {session_label}"
    text = f"""New SAT Math booking

Parent / guardian: {g('parent_name')}
Student: {g('student_name')}
Service: {'Single 60-minute session ($70)' if g('service_option') == 'single' else 'Free first session — 4-Week SAT Math Accelerator'}
Language: {'Portuguese' if g('language') == 'pt' else 'English'}
Email: {g('email')}
Phone: {display_phone(g('phone'))}
Booked time: {session_label}
Parent browser timezone: {g('timezone') or 'Not provided'}
Source: {source}

Lead status: NEW
Received: {g('created_at')}

Reply directly to this email or text/call the parent using the phone number above.
"""
    return subject, text


def parent_confirmation_email(lead: sqlite3.Row | dict) -> tuple[str, str]:
    def g(key):
        try:
            return lead[key]
        except Exception:
            return ""
    session_label = business_datetime_label(g("preferred_session"), "pt" if g("language") == "pt" else "en")
    if g("service_option") == "single":
        if g("language") == "pt":
            subject = "Sua aula de Matemática do SAT está agendada"
            intro = f"Sua aula particular de 60 minutos de Matemática do SAT para {g('student_name')} está agendada."
            close = "O valor da aula avulsa é US$ 70. Enviarei por e-mail os detalhes de pagamento e da aula."
        else:
            subject = "Your SAT Math session is booked"
            intro = f"Your private 60-minute SAT Math session for {g('student_name')} is booked."
            close = "The single-session rate is $70. I’ll send any payment/session details by email."
    else:
        subject = "Your free SAT Math Accelerator session is booked"
        if g("language") == "pt":
            subject = "Sua aula gratuita do Acelerador de Matemática do SAT está agendada"
            intro = f"Sua primeira aula gratuita de 50 minutos do Acelerador de Matemática do SAT em 4 Semanas para {g('student_name')} está agendada."
            close = "Não há pagamento para esta primeira aula. Se decidir continuar depois, o Acelerador de 4 Semanas custa US$ 200 por quatro aulas de 60 minutos."
        else:
            intro = f"Your free 50-minute first session of the 4-Week SAT Math Accelerator for {g('student_name')} is booked."
            close = "There is no payment for this first session. If you decide to continue afterward, the 4-Week Accelerator is $200 for four paid 60-minute sessions."
    if g("language") == "pt":
        text = f"""Olá {g('parent_name')},

{intro}

Horário agendado: {session_label}

{close}

Alguma dúvida antes da aula? Fale comigo diretamente pelo número {PUBLIC_PHONE}.

— Pedro
Math with Pedro
"""
    else:
        text = f"""Hi {g('parent_name')},

{intro}

Booked time: {session_label}

{close}

Questions before the session? Text me directly at {PUBLIC_PHONE}.

— Pedro
Math with Pedro
"""
    return subject, text


def rate_limit_ok(environ) -> bool:
    hashed = ip_hash(client_ip(environ))
    cutoff = (utcnow() - timedelta(hours=1)).isoformat(timespec="seconds")
    con = db_conn()
    con.execute("DELETE FROM lead_attempts WHERE created_at < ?", ((utcnow() - timedelta(days=2)).isoformat(timespec="seconds"),))
    count = con.execute("SELECT COUNT(*) c FROM lead_attempts WHERE ip_hash=? AND created_at>=?", (hashed, cutoff)).fetchone()["c"]
    if count >= 8:
        con.commit(); con.close(); return False
    con.execute("INSERT INTO lead_attempts(ip_hash,created_at) VALUES(?,?)", (hashed, iso_now()))
    con.commit(); con.close(); return True


def auth_rate_limit_ok(environ, scope: str, max_attempts: int, window_minutes: int) -> bool:
    hashed = ip_hash(client_ip(environ))
    cutoff = (utcnow() - timedelta(minutes=window_minutes)).isoformat(timespec="seconds")
    con = db_conn()
    con.execute("DELETE FROM auth_attempts WHERE created_at < ?", ((utcnow() - timedelta(days=2)).isoformat(timespec="seconds"),))
    count = con.execute("SELECT COUNT(*) c FROM auth_attempts WHERE scope=? AND ip_hash=? AND created_at>=?", (scope, hashed, cutoff)).fetchone()["c"]
    if count >= max_attempts:
        con.commit(); con.close(); return False
    con.execute("INSERT INTO auth_attempts(scope,ip_hash,created_at) VALUES(?,?,?)", (scope, hashed, iso_now()))
    con.commit(); con.close(); return True


def validate_lead(form: dict[str, str]) -> tuple[bool, str]:
    if form.get("website", "").strip():  # honeypot
        return False, "bot"
    required = ["parent_name", "student_name", "email", "phone", "preferred_session", "consent"]
    if any(not form.get(k, "").strip() for k in required):
        return False, "Please complete all required fields and choose an available session time."
    if not EMAIL_RE.match(form.get("email", "").strip()):
        return False, "Please enter a valid email address."
    phone = normalize_phone(form.get("phone", ""))
    if not 10 <= len(phone) <= 15:
        return False, "Please enter a valid phone number."
    try:
        dt = datetime.fromisoformat(form.get("preferred_session", "").replace("Z", "+00:00"))
        if dt.tzinfo is None:
            return False, "Please choose a valid session time."
    except ValueError:
        return False, "Please choose a valid session time."
    return True, ""


def store_lead(form: dict[str, str]) -> tuple[int, bool, str]:
    email = clamp(form.get("email", "").lower(), 254)
    phone = display_phone(clamp(form.get("phone", ""), 40))
    service = "single" if form.get("service_option") == "single" else "accelerator"
    preferred = clamp(form.get("preferred_session", ""), 60)
    try:
        selected_dt = datetime.fromisoformat(preferred.replace("Z", "+00:00"))
        if selected_dt.tzinfo is None:
            raise ValueError
        selected_dt = selected_dt.astimezone(timezone.utc)
        preferred = selected_dt.isoformat(timespec="seconds")
        business_date = selected_dt.astimezone(BUSINESS_TZ).date().isoformat()
    except ValueError:
        return 0, False, "Please choose a valid available session time."

    con = db_conn()
    try:
        con.execute("BEGIN IMMEDIATE")
        duplicate = con.execute(
            "SELECT id FROM leads WHERE email=? AND preferred_session=? AND created_at>=?",
            (email, preferred, (utcnow() - timedelta(minutes=10)).isoformat(timespec="seconds")),
        ).fetchone()
        if duplicate:
            con.commit()
            return int(duplicate["id"]), False, ""

        open_slots = {slot["start_utc"]: slot for slot in available_slots_for_date(business_date, service, con)}
        slot = open_slots.get(preferred)
        if not slot:
            con.rollback()
            return 0, False, "That time is no longer available. Please choose another open time."

        lead_sql = """INSERT INTO leads(
                created_at,parent_name,student_name,email,phone,current_score,target_score,
                preferred_session,alternate_session,timezone,utm_source,utm_medium,
                utm_campaign,utm_content,referrer,service_option,language,status,notification_status,confirmation_status
            ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""" + (" RETURNING id" if DATABASE_URL else "")
        cur = con.execute(
            lead_sql,
            (
                iso_now(), clamp(form.get("parent_name"),100), clamp(form.get("student_name"),100), email, phone,
                "", "", preferred, "", clamp(form.get("timezone"),80),
                clamp(form.get("utm_source"),100), clamp(form.get("utm_medium"),100),
                clamp(form.get("utm_campaign"),160), clamp(form.get("utm_content"),160),
                clamp(form.get("referrer"),200), service, ("pt" if form.get("language") == "pt" else "en"), "new", "pending", "pending",
            ),
        )
        lead_id = int(cur.fetchone()["id"] if DATABASE_URL else cur.lastrowid)
        con.execute(
            "INSERT INTO appointments(lead_id,start_utc,end_utc,service_option,created_at,status) VALUES(?,?,?,?,?,?)",
            (lead_id, preferred, slot["end_utc"], service, iso_now(), "booked"),
        )
        con.commit()
        return lead_id, True, ""
    except (sqlite3.IntegrityError, psycopg.IntegrityError if psycopg else sqlite3.IntegrityError):
        con.rollback()
        return 0, False, "That time was just booked by another family. Please choose another open time."
    finally:
        con.close()


def notify_for_lead(lead_id: int) -> None:
    con = db_conn()
    lead = con.execute("SELECT * FROM leads WHERE id=?", (lead_id,)).fetchone()
    con.close()
    if not lead:
        return
    notify_status = "not_configured"
    confirmation_status = "not_configured"
    if smtp_configured():
        try:
            if LEAD_NOTIFY_TO:
                subject, text = lead_owner_email(lead)
                send_email(LEAD_NOTIFY_TO, subject, text, reply_to=lead["email"])
                notify_status = "sent"
            else:
                notify_status = "no_recipient"
        except Exception as exc:
            notify_status = "failed"
            log.exception("Lead notification email failed for lead %s: %s", lead_id, exc)
        try:
            subject, text = parent_confirmation_email(lead)
            send_email(lead["email"], subject, text)
            confirmation_status = "sent"
        except Exception as exc:
            confirmation_status = "failed"
            log.exception("Parent confirmation email failed for lead %s: %s", lead_id, exc)
    con = db_conn()
    con.execute("UPDATE leads SET notification_status=?, confirmation_status=? WHERE id=?", (notify_status, confirmation_status, lead_id))
    con.commit(); con.close()


def admin_session(environ):
    token = parse_cookies(environ).get("mwp_admin")
    if not token:
        return None
    con = db_conn()
    row = con.execute("SELECT * FROM admin_sessions WHERE token=? AND expires_at>?", (token, iso_now())).fetchone()
    con.close()
    return row


def student_session(environ):
    token = parse_cookies(environ).get("mwp_session")
    if not token:
        return None, None
    con = db_conn()
    row = con.execute(
        """SELECT u.*, s.csrf_token FROM student_sessions s
           JOIN users u ON u.id=s.user_id WHERE s.token=? AND s.expires_at>?""",
        (token, iso_now()),
    ).fetchone()
    con.close()
    return (row, row["csrf_token"] if row else None)


def admin_login_page(error="") -> str:
    err = f'<div class="form-error">{esc(error)}</div>' if error else ""
    return f'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><title>Admin Login | Math with Pedro</title><link rel="stylesheet" href="static/site.css"></head><body><main class="login-page"><div class="login-shell"><a class="brand" href="/"><span class="brand-mark">M</span><span>Math with Pedro</span></a><div class="login-card"><div class="kicker">ADMIN</div><h1>Lead dashboard.</h1>{err}<form method="post" action="/admin/login"><label>Password<input required type="password" name="password" autocomplete="current-password"></label><button class="button button-primary full" type="submit">Log In</button></form></div><a class="back-home" href="/">← Back to site</a></div></main></body></html>'''


def admin_dashboard(session_row) -> str:
    con = db_conn()
    leads = con.execute("SELECT * FROM leads ORDER BY id DESC LIMIT 500").fetchall()
    students = con.execute("SELECT id,name,email,current_score,target_score FROM users ORDER BY id DESC LIMIT 100").fetchall()
    windows = con.execute("SELECT * FROM weekly_availability ORDER BY weekday,start_time").fetchall()
    blocked = con.execute("SELECT * FROM blocked_dates WHERE date>=? ORDER BY date LIMIT 60", (datetime.now(BUSINESS_TZ).date().isoformat(),)).fetchall()
    appts = con.execute("SELECT a.id,a.start_utc,a.end_utc,a.service_option,a.status,l.parent_name,l.student_name,l.phone FROM appointments a JOIN leads l ON l.id=a.lead_id WHERE a.status='booked' AND a.start_utc>=? ORDER BY a.start_utc LIMIT 80", (iso_now(),)).fetchall()
    con.close()
    csrf = esc(session_row["csrf_token"])
    lead_rows = []
    for l in leads:
        source = " / ".join(x for x in [l["utm_source"], l["utm_campaign"]] if x) or l["referrer"] or "Direct / unknown"
        options = "".join(f'<option value="{st}" {"selected" if l["status"]==st else ""}>{st.title()}</option>' for st in ["new","contacted","scheduled","converted","closed"])
        session_label = business_datetime_label(l["preferred_session"])
        lead_rows.append(f'''<tr><td><b>#{l['id']}</b><br><small>{esc(l['created_at'][:16].replace('T',' '))} UTC</small></td><td><b>{esc(l['parent_name'])}</b><br>{esc(l['email'])}<br>{esc(l['phone'])}<br><small>Student: {esc(l['student_name'])}<br>Service: {('Single $70' if l['service_option']=='single' else '4-Week Accelerator')}<br>Language: {('PT' if l['language']=='pt' else 'EN')}</small></td><td><b>{esc(session_label)}</b><br><small>Browser TZ: {esc(l['timezone']) or '—'}</small></td><td><small>{esc(source)}</small></td><td><small>Owner: {esc(l['notification_status'])}<br>Parent: {esc(l['confirmation_status'])}</small></td><td><form method="post" action="/admin/leads/{l['id']}/status"><input type="hidden" name="csrf" value="{csrf}"><select name="status">{options}</select><button class="admin-mini" type="submit">Save</button></form><form method="post" action="/admin/leads/{l['id']}/resend"><input type="hidden" name="csrf" value="{csrf}"><button class="admin-link" type="submit">Resend emails</button></form></td></tr>''')
    if not lead_rows:
        lead_rows.append('<tr><td colspan="6">No leads yet.</td></tr>')

    weekday_names = ["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"]
    grouped = {i: [] for i in range(7)}
    for w in windows:
        grouped[w["weekday"]].append(w)
    schedule_blocks = []
    for i,name in enumerate(weekday_names):
        entries = []
        for w in grouped[i]:
            entries.append(f'''<span class="window-chip">{esc(w['start_time'])}–{esc(w['end_time'])}<form method="post" action="/admin/availability/delete" style="display:inline"><input type="hidden" name="csrf" value="{csrf}"><input type="hidden" name="id" value="{w['id']}"><button title="Delete window" type="submit">×</button></form></span>''')
        schedule_blocks.append(f'<div class="day-row"><b>{name}</b><div>{"".join(entries) or "<small>No hours</small>"}</div></div>')
    blocked_rows = "".join(f'''<li><b>{esc(b['date'])}</b>{' — '+esc(b['reason']) if b['reason'] else ''}<form method="post" action="/admin/availability/unblock" style="display:inline"><input type="hidden" name="csrf" value="{csrf}"><input type="hidden" name="date" value="{esc(b['date'])}"><button type="submit">Unblock</button></form></li>''' for b in blocked) or '<li>No upcoming blocked dates.</li>'
    appt_rows = "".join(f'''<tr><td>{esc(business_datetime_label(a['start_utc']))}</td><td>{esc(a['student_name'])}</td><td>{esc(a['parent_name'])}<br><small>{esc(a['phone'])}</small></td><td>{'Single $70' if a['service_option']=='single' else 'Free Accelerator'}</td><td><form method="post" action="/admin/appointments/{a['id']}/release"><input type="hidden" name="csrf" value="{csrf}"><button type="submit">Release slot</button></form></td></tr>''' for a in appts) or '<tr><td colspan="5">No upcoming bookings.</td></tr>'
    student_rows = "".join(f'<li><b>{esc(st["name"])}</b> — {esc(st["email"])} — {esc(st["current_score"])} → {esc(st["target_score"])}</li>' for st in students) or '<li>No student accounts yet.</li>'

    return f'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><title>Admin | Math with Pedro</title><style>
    body{{font-family:system-ui;margin:0;background:#f7f8fb;color:#0d2547}} .a-wrap{{max-width:1400px;margin:auto;padding:28px}} .a-head{{display:flex;justify-content:space-between;align-items:center;gap:20px;flex-wrap:wrap}} .a-actions a{{margin-left:12px}} table{{width:100%;border-collapse:collapse;background:#fff;margin-top:24px;font-size:14px}} th,td{{padding:12px;border:1px solid #dde3ed;vertical-align:top;text-align:left}} th{{background:#eef3fa}} select{{min-height:34px}} .admin-mini,.admin-link{{margin-top:6px;min-height:32px;cursor:pointer}} .cards{{display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-top:30px}} .card{{background:#fff;border:1px solid #dde3ed;padding:20px;border-radius:12px}} input,select{{box-sizing:border-box;min-height:40px;margin:6px 0 12px;padding:8px}} input{{display:block;width:100%}} button{{padding:8px 12px;cursor:pointer}} .availability-card{{grid-column:1/-1}} .schedule-grid{{display:grid;grid-template-columns:repeat(2,1fr);gap:8px 20px;margin:18px 0}} .day-row{{display:grid;grid-template-columns:95px 1fr;gap:10px;align-items:start;padding:8px 0;border-bottom:1px solid #edf0f4}} .window-chip{{display:inline-flex;align-items:center;gap:4px;background:#eef4ff;border-radius:999px;padding:4px 5px 4px 9px;margin:0 5px 5px 0;font-size:12px}} .window-chip button{{border:0;background:transparent;padding:0 5px;font-size:16px}} .inline-form{{display:grid;grid-template-columns:1.1fr 1fr 1fr auto;gap:10px;align-items:end}} .inline-form label{{font-size:12px}} .block-form{{display:grid;grid-template-columns:1fr 1.5fr auto;gap:10px;align-items:end}} .blocked-list{{padding-left:20px}} .blocked-list form{{margin-left:8px}} .subtle{{color:#66758a;font-size:13px}} @media(max-width:800px){{.a-wrap{{padding:14px;overflow:auto}} .cards{{grid-template-columns:1fr}} table{{min-width:900px}} .schedule-grid{{grid-template-columns:1fr}} .inline-form,.block-form{{grid-template-columns:1fr}}}}
    </style></head><body><main class="a-wrap"><div class="a-head"><div><h1>Lead dashboard</h1><p>{len(leads)} most recent leads · database: {esc(str(DB_PATH))}</p></div><div class="a-actions"><form method="post" action="/admin/test-email" style="display:inline"><input type="hidden" name="csrf" value="{csrf}"><button type="submit">Send test email</button></form><a href="/admin/export.csv">Export CSV</a><a href="/admin/logout">Log out</a></div></div>
    <table><thead><tr><th>Lead</th><th>Contact</th><th>Booked session</th><th>Source</th><th>Email delivery</th><th>Status</th></tr></thead><tbody>{''.join(lead_rows)}</tbody></table>
    <div class="cards">
      <section class="card availability-card"><h2>Booking availability</h2><p class="subtle">Times are configured in Eastern Time (Orlando). Free Accelerator sessions use 50 minutes; single sessions use 60 minutes. A {BOOKING_BUFFER_MINUTES}-minute buffer is automatically protected after bookings.</p>
        <div class="schedule-grid">{''.join(schedule_blocks)}</div>
        <h3>Add recurring weekly hours</h3><form class="inline-form" method="post" action="/admin/availability/add"><input type="hidden" name="csrf" value="{csrf}"><label>Day<select name="weekday" required>{''.join(f'<option value="{i}">{n}</option>' for i,n in enumerate(weekday_names))}</select></label><label>Start<input required type="time" name="start_time"></label><label>End<input required type="time" name="end_time"></label><button type="submit">Add hours</button></form>
        <h3>Block a specific date</h3><form class="block-form" method="post" action="/admin/availability/block"><input type="hidden" name="csrf" value="{csrf}"><label>Date<input required type="date" name="date"></label><label>Reason <span class="subtle">optional</span><input name="reason" maxlength="120" placeholder="Travel, exam, etc."></label><button type="submit">Block date</button></form>
        <ul class="blocked-list">{blocked_rows}</ul>
        <h3>Upcoming bookings</h3><table><thead><tr><th>Time</th><th>Student</th><th>Parent</th><th>Service</th><th>Action</th></tr></thead><tbody>{appt_rows}</tbody></table>
      </section>
      <section class="card"><h2>Create student login</h2><form method="post" action="/admin/students/create"><input type="hidden" name="csrf" value="{csrf}"><label>Student name<input required name="name"></label><label>Email<input required type="email" name="email"></label><label>Temporary password<input required type="password" name="password" minlength="10"></label><label>Current score<input name="current_score" inputmode="numeric"></label><label>Target score<input name="target_score" inputmode="numeric"></label><button type="submit">Create student</button></form></section>
      <section class="card"><h2>Student accounts</h2><ul>{student_rows}</ul><p><small>Student passwords are stored only as salted PBKDF2 hashes.</small></p></section>
    </div></main></body></html>'''

def login_page(error="", lang="en") -> str:
    template = (ROOT / ("pt/login.html" if lang == "pt" else "login.html")).read_text(encoding="utf-8")
    # The static file contains a hidden error box so it can still be previewed locally.
    if error:
        template = template.replace('<div id="login-error" class="form-error" style="display:none"></div>', f'<div id="login-error" class="form-error">{esc(error)}</div>')
    return template


def portal_page(user: sqlite3.Row, csrf_token: str, message="") -> str:
    con = db_conn()
    assignments = con.execute("SELECT * FROM assignments WHERE user_id=? ORDER BY complete, due_date", (user["id"],)).fetchall()
    scores = con.execute("SELECT * FROM score_history WHERE user_id=? ORDER BY recorded_at", (user["id"],)).fetchall()
    notes = con.execute("SELECT * FROM session_notes WHERE user_id=? ORDER BY session_date DESC", (user["id"],)).fetchall()
    con.close()
    ahtml = "".join(f'''<div class="assignment {'done' if a['complete'] else ''}"><span class="assignment-check">{'✓' if a['complete'] else ''}</span><div><b>{esc(a['title'])}</b><p>{esc(a['detail'])}</p></div><small>{esc(a['due_date'])}</small></div>''' for a in assignments) or '<p>No assignments yet.</p>'
    shtml = "".join(f'''<div class="score-point"><div class="score-bar" style="height:{max(16,int(a['score']/800*100))}%"></div><b>{a['score']}</b><span>{esc(a['label'])}</span></div>''' for a in scores) or '<p>No Bluebook scores yet.</p>'
    nhtml = "".join(f'''<article class="note-card"><small>{esc(n['session_date'])}</small><h3>{esc(n['topic'])}</h3><p>{esc(n['notes'])}</p></article>''' for n in notes) or '<p>No session notes yet.</p>'
    msg = f'<div class="portal-message">{esc(message)}</div>' if message else ""
    first = esc((user["name"] or "Student").split()[0])
    return f'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><title>Student Portal | Math with Pedro</title><link rel="stylesheet" href="static/site.css"></head><body><div class="portal-app"><aside class="portal-sidebar"><a class="brand portal-brand" href="/"><span class="brand-mark">M</span><span>Math with Pedro</span></a><nav><a class="active" href="#overview">Overview</a><a href="#assignments">Assignments</a><a href="#scores">Bluebook Scores</a><a href="#notes">Session Notes</a><a href="#schedule">Schedule</a></nav><div class="student-mini"><span>{esc(user['name'])}</span><a href="/logout">Log out</a></div></aside><main class="portal-main"><header><div><small>STUDENT PORTAL</small><h1>Hi, {first}.</h1></div><div class="portal-date">{datetime.now().strftime('%B %d, %Y')}</div></header>{msg}<section id="overview" class="portal-summary"><div class="summary-card hero-summary"><span>CURRENT → TARGET</span><strong>{esc(user['current_score'])} <i>→</i> {esc(user['target_score'])}+</strong><small>SAT Math</small></div><div class="summary-card"><span>NEXT SESSION</span><strong class="smaller">{esc(user['next_session']) or 'Not scheduled'}</strong><small>Private 60-minute session</small></div><div class="summary-card"><span>CURRENT FOCUS</span><strong class="smaller">{esc(user['current_focus']) or 'To be set'}</strong><small>Updated from recent work</small></div></section><section id="assignments" class="portal-section"><div class="portal-section-head"><div><small>THIS WEEK</small><h2>Assignments</h2></div></div><div class="assignment-list">{ahtml}</div></section><section id="scores" class="portal-section"><div class="portal-section-head"><div><small>PROGRESS</small><h2>Bluebook scores</h2></div></div><div class="score-chart">{shtml}</div></section><section id="notes" class="portal-section"><div class="portal-section-head"><div><small>REVIEW</small><h2>Session notes</h2></div></div><div class="notes-grid">{nhtml}</div></section><section id="schedule" class="portal-section"><div class="portal-section-head"><div><small>SCHEDULING</small><h2>Request a reschedule</h2></div></div><form class="reschedule-form" method="post" action="/reschedule"><input type="hidden" name="csrf" value="{esc(csrf_token)}"><label>Preferred new date / time<input required name="requested_time" placeholder="Example: Friday after 5 PM"></label><label>Note<textarea name="note" rows="3" placeholder="Optional"></textarea></label><button class="button button-primary" type="submit">Send Request</button></form></section></main></div><script src="/static/site.js"></script></body></html>'''


def privacy_page() -> str:
    contact = esc(PUBLIC_CONTACT_EMAIL) if PUBLIC_CONTACT_EMAIL else "the contact information in your session confirmation"
    return f'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Privacy | Math with Pedro</title><link rel="stylesheet" href="static/site.css"></head><body><header class="site-header"><div class="shell nav-wrap"><a class="brand" href="/"><span class="brand-mark">M</span><span>Math with Pedro</span></a></div></header><main class="section shell" style="max-width:820px"><div class="kicker">PRIVACY</div><h1 style="font-size:clamp(2.5rem,6vw,4.5rem)">Privacy policy</h1><p><b>Last updated: September 28, 2026.</b></p><h2>What is collected</h2><p>When a parent or guardian books a session, Math with Pedro collects the parent/guardian name, email address, phone number, the student’s first name, booked session time, browser timezone, and basic referral/source information used to understand which outreach channels are working.</p><h2>How it is used</h2><p>This information is used to book and communicate about tutoring sessions, prepare for tutoring, provide tutoring services if you continue, and operate the student portal. It is not sold to advertisers.</p><h2>Children</h2><p>The booking form is intended to be submitted by a parent or guardian when the student is under 18.</p><h2>Retention</h2><p>Lead information that does not become an active tutoring relationship may be removed after 12 months. Active-client records may be kept as needed to deliver tutoring and maintain ordinary business records.</p><h2>Email and text</h2><p>Submitting the booking form allows Pedro to contact you by email or text about the session you booked. It does not enroll you in unrelated marketing messages.</p><h2>Requests</h2><p>You can request access, correction, or deletion of your lead information by contacting {contact} or texting {esc(PUBLIC_PHONE)}.</p><p><a href="/">← Back to Math with Pedro</a></p></main></body></html>'''


def validate_admin_csrf(environ, form) -> bool:
    sess = admin_session(environ)
    return bool(sess and form.get("csrf") and hmac.compare_digest(form.get("csrf"), sess["csrf_token"]))


def export_csv() -> bytes:
    con = db_conn(); rows = con.execute("SELECT * FROM leads ORDER BY id DESC").fetchall(); con.close()
    out = io.StringIO(); writer = csv.writer(out)
    cols = ["id","created_at","parent_name","student_name","email","phone","preferred_session","timezone","utm_source","utm_medium","utm_campaign","utm_content","referrer","service_option","language","status","notification_status","confirmation_status"]
    writer.writerow(cols)
    for row in rows:
        writer.writerow([row[c] for c in cols])
    return out.getvalue().encode("utf-8-sig")


def route(environ, start_response):
    method = environ.get("REQUEST_METHOD", "GET").upper()
    path = unquote(environ.get("PATH_INFO", "/"))

    if path == "/healthz":
        try:
            con = db_conn(); con.execute("SELECT 1").fetchone(); con.close()
            payload = json.dumps({"ok": True})
            return respond(start_response, environ, payload, content_type="application/json; charset=utf-8", sensitive=True)
        except Exception as exc:
            return respond(start_response, environ, json.dumps({"ok": False, "error": str(exc)}), "503 Service Unavailable", "application/json; charset=utf-8", sensitive=True)

    if method == "GET" and path == "/api/availability":
        q = query_params(environ)
        service = "single" if q.get("service") == "single" else "accelerator"
        try:
            days = int(q.get("days", "28"))
        except ValueError:
            days = 28
        payload = json.dumps(availability_payload(service, days))
        return respond(start_response, environ, payload, content_type="application/json; charset=utf-8", sensitive=True)

    if path.startswith("/static/") and method == "GET":
        return static_file(start_response, environ, path.lstrip("/"))

    if method == "GET" and path in {"/", "/index.html"}:
        return static_file(start_response, environ, "index.html")
    if method == "GET" and path in {"/pt", "/pt/", "/pt/index.html"}:
        return static_file(start_response, environ, "pt/index.html")
    if method == "GET" and path in {"/apply", "/apply.html"}:
        return static_file(start_response, environ, "apply.html")
    if method == "GET" and path in {"/pt/apply", "/pt/apply.html"}:
        return static_file(start_response, environ, "pt/apply.html")
    if method == "GET" and path in {"/success", "/success.html"}:
        return static_file(start_response, environ, "success.html")
    if method == "GET" and path in {"/pt/success", "/pt/success.html"}:
        return static_file(start_response, environ, "pt/success.html")
    if method == "GET" and path in {"/privacy", "/privacy.html"}:
        return static_file(start_response, environ, "privacy.html")
    if method == "GET" and path in {"/pt/privacy", "/pt/privacy.html"}:
        return static_file(start_response, environ, "pt/privacy.html")

    if path in {"/login", "/login.html", "/pt/login", "/pt/login.html"}:
        if method == "GET":
            return respond(start_response, environ, login_page(lang="pt" if path.startswith("/pt/") else "en"), sensitive=True)
        if method == "POST":
            if not auth_rate_limit_ok(environ, "student_login", 20, 60):
                return respond(start_response, environ, login_page("Muitas tentativas de login. Tente novamente mais tarde." if path.startswith("/pt/") else "Too many login attempts. Please try again later.", lang="pt" if path.startswith("/pt/") else "en"), "429 Too Many Requests", sensitive=True)
            form = read_form(environ)
            email = clamp(form.get("email", "").lower(), 254)
            con = db_conn(); user = con.execute("SELECT * FROM users WHERE email=?", (email,)).fetchone()
            if not user or not verify_password(form.get("password", ""), user["salt"], user["password_hash"]):
                con.close(); return respond(start_response, environ, login_page("E-mail ou senha incorretos." if path.startswith("/pt/") else "Incorrect email or password.", lang="pt" if path.startswith("/pt/") else "en"), "401 Unauthorized", sensitive=True)
            token = secrets.token_urlsafe(36); csrf = secrets.token_urlsafe(24)
            exp = (utcnow() + timedelta(days=14)).isoformat(timespec="seconds")
            con.execute("INSERT INTO student_sessions(token,user_id,csrf_token,expires_at) VALUES(?,?,?,?)", (token, user["id"], csrf, exp)); con.commit(); con.close()
            return redirect(start_response, environ, "/portal", [("Set-Cookie", cookie_header("mwp_session", token, 1209600))])

    if method == "GET" and path == "/portal":
        user, csrf = student_session(environ)
        if not user:
            return redirect(start_response, environ, "/login")
        return respond(start_response, environ, portal_page(user, csrf), sensitive=True)

    if method == "GET" and path == "/logout":
        token = parse_cookies(environ).get("mwp_session")
        if token:
            con = db_conn(); con.execute("DELETE FROM student_sessions WHERE token=?", (token,)); con.commit(); con.close()
        return redirect(start_response, environ, "/", [("Set-Cookie", cookie_header("mwp_session", "", 0, clear=True))])

    if method == "POST" and path == "/reschedule":
        user, csrf = student_session(environ)
        if not user:
            return redirect(start_response, environ, "/login")
        form = read_form(environ)
        if not form.get("csrf") or not hmac.compare_digest(form.get("csrf"), csrf):
            return respond(start_response, environ, "Invalid request", "403 Forbidden", "text/plain; charset=utf-8", sensitive=True)
        requested = clamp(form.get("requested_time"), 120)
        if not requested:
            return redirect(start_response, environ, "/portal#schedule")
        con = db_conn(); con.execute("INSERT INTO reschedule_requests(user_id,created_at,requested_time,note) VALUES(?,?,?,?)", (user["id"], iso_now(), requested, clamp(form.get("note"), 500))); con.commit(); con.close()
        return respond(start_response, environ, portal_page(user, csrf, "Reschedule request sent."), sensitive=True)

    if method == "POST" and path in {"/apply", "/pt/apply"}:
        form = read_form(environ)
        if path == "/pt/apply":
            form["language"] = "pt"
        valid, reason = validate_lead(form)
        if reason == "bot":
            return redirect(start_response, environ, "/pt/success" if form.get("language") == "pt" else "/success")
        if not rate_limit_ok(environ):
            return respond(start_response, environ, "Too many requests. Please try again later.", "429 Too Many Requests", "text/plain; charset=utf-8", sensitive=True)
        if not valid:
            if form.get("language") == "pt":
                pt_reason = {"Please complete all required fields and choose an available session time.": "Preencha todos os campos obrigatórios e escolha um horário disponível.", "Please enter a valid email address.": "Digite um e-mail válido.", "Please enter a valid phone number.": "Digite um telefone válido.", "Please choose a valid session time.": "Escolha um horário de aula válido."}.get(reason, reason)
                return respond(start_response, environ, f"<h1>Não foi possível concluir o agendamento.</h1><p>{esc(pt_reason)}</p><p><a href='/pt/apply'>Voltar</a></p>", "400 Bad Request", sensitive=True)
            return respond(start_response, environ, f"<h1>We couldn't submit that request.</h1><p>{esc(reason)}</p><p><a href='/apply'>Go back</a></p>", "400 Bad Request", sensitive=True)
        lead_id, created, booking_error = store_lead(form)
        if booking_error:
            if form.get("language") == "pt":
                return respond(start_response, environ, f"<h1>Esse horário não está mais disponível.</h1><p>Escolha outro horário disponível.</p><p><a href='/pt/apply'>Escolher outro horário</a></p>", "409 Conflict", sensitive=True)
            return respond(start_response, environ, f"<h1>That time is no longer available.</h1><p>{esc(booking_error)}</p><p><a href='/apply'>Choose another time</a></p>", "409 Conflict", sensitive=True)
        if created:
            notify_for_lead(lead_id)
        prefix = "/pt" if form.get("language") == "pt" else ""
        success_url = f"{prefix}/success?option=single" if form.get("service_option") == "single" else f"{prefix}/success"
        return redirect(start_response, environ, success_url)

    if path == "/admin/login":
        if method == "GET":
            if not ADMIN_PASSWORD:
                return respond(start_response, environ, "Admin login is not configured.", "503 Service Unavailable", "text/plain; charset=utf-8", sensitive=True)
            return respond(start_response, environ, admin_login_page(), sensitive=True)
        if method == "POST":
            if not ADMIN_PASSWORD:
                return respond(start_response, environ, "Admin login is not configured.", "503 Service Unavailable", "text/plain; charset=utf-8", sensitive=True)
            if not auth_rate_limit_ok(environ, "admin_login", 10, 60):
                return respond(start_response, environ, admin_login_page("Too many login attempts. Please try again later."), "429 Too Many Requests", sensitive=True)
            form = read_form(environ)
            if not hmac.compare_digest(form.get("password", ""), ADMIN_PASSWORD):
                return respond(start_response, environ, admin_login_page("Incorrect password."), "401 Unauthorized", sensitive=True)
            token = secrets.token_urlsafe(36); csrf = secrets.token_urlsafe(24); exp = (utcnow() + timedelta(hours=12)).isoformat(timespec="seconds")
            con = db_conn(); con.execute("INSERT INTO admin_sessions(token,csrf_token,expires_at) VALUES(?,?,?)", (token, csrf, exp)); con.commit(); con.close()
            return redirect(start_response, environ, "/admin", [("Set-Cookie", cookie_header("mwp_admin", token, 43200))])

    if method == "GET" and path == "/admin/logout":
        token = parse_cookies(environ).get("mwp_admin")
        if token:
            con = db_conn(); con.execute("DELETE FROM admin_sessions WHERE token=?", (token,)); con.commit(); con.close()
        return redirect(start_response, environ, "/admin/login", [("Set-Cookie", cookie_header("mwp_admin", "", 0, clear=True))])

    if method == "GET" and path == "/admin":
        sess = admin_session(environ)
        if not sess:
            return redirect(start_response, environ, "/admin/login")
        return respond(start_response, environ, admin_dashboard(sess), sensitive=True)

    if method == "GET" and path == "/admin/export.csv":
        sess = admin_session(environ)
        if not sess:
            return redirect(start_response, environ, "/admin/login")
        return respond(start_response, environ, export_csv(), content_type="text/csv; charset=utf-8", extra_headers=[("Content-Disposition", "attachment; filename=math-with-pedro-leads.csv")], sensitive=True)

    m = re.fullmatch(r"/admin/leads/(\d+)/(status|resend)", path)
    if method == "POST" and m:
        sess = admin_session(environ)
        if not sess:
            return redirect(start_response, environ, "/admin/login")
        form = read_form(environ)
        if not validate_admin_csrf(environ, form):
            return respond(start_response, environ, "Invalid CSRF token", "403 Forbidden", "text/plain; charset=utf-8", sensitive=True)
        lead_id = int(m.group(1)); action = m.group(2)
        if action == "status":
            status = form.get("status", "")
            if status not in ALLOWED_STATUSES:
                return respond(start_response, environ, "Invalid status", "400 Bad Request", "text/plain; charset=utf-8", sensitive=True)
            con = db_conn(); con.execute("UPDATE leads SET status=? WHERE id=?", (status, lead_id)); con.commit(); con.close()
        else:
            notify_for_lead(lead_id)
        return redirect(start_response, environ, "/admin")

    if method == "POST" and path == "/admin/test-email":
        sess = admin_session(environ)
        if not sess:
            return redirect(start_response, environ, "/admin/login")
        form = read_form(environ)
        if not validate_admin_csrf(environ, form):
            return respond(start_response, environ, "Invalid CSRF token", "403 Forbidden", "text/plain; charset=utf-8", sensitive=True)
        if not LEAD_NOTIFY_TO or not smtp_configured():
            return respond(start_response, environ, "SMTP or LEAD_NOTIFY_TO is not configured.", "503 Service Unavailable", "text/plain; charset=utf-8", sensitive=True)
        try:
            send_email(LEAD_NOTIFY_TO, "Math with Pedro — notification test", "Your lead notification email is configured correctly.")
        except Exception as exc:
            log.exception("SMTP test failed: %s", exc)
            return respond(start_response, environ, "SMTP test failed. Check server logs and email settings.", "502 Bad Gateway", "text/plain; charset=utf-8", sensitive=True)
        return redirect(start_response, environ, "/admin")

    if method == "POST" and path in {"/admin/availability/add", "/admin/availability/delete", "/admin/availability/block", "/admin/availability/unblock"}:
        sess = admin_session(environ)
        if not sess:
            return redirect(start_response, environ, "/admin/login")
        form = read_form(environ)
        if not validate_admin_csrf(environ, form):
            return respond(start_response, environ, "Invalid CSRF token", "403 Forbidden", "text/plain; charset=utf-8", sensitive=True)
        con = db_conn()
        try:
            if path.endswith("/add"):
                try:
                    weekday = int(form.get("weekday", "-1"))
                except ValueError:
                    weekday = -1
                start_time = clamp(form.get("start_time"), 5); end_time = clamp(form.get("end_time"), 5)
                if weekday not in range(7) or not _parse_time(start_time) or not _parse_time(end_time) or start_time >= end_time:
                    return respond(start_response, environ, "Invalid availability window", "400 Bad Request", "text/plain; charset=utf-8", sensitive=True)
                exists = con.execute("SELECT 1 FROM weekly_availability WHERE weekday=? AND start_time=? AND end_time=?", (weekday,start_time,end_time)).fetchone()
                if not exists:
                    con.execute("INSERT INTO weekly_availability(weekday,start_time,end_time) VALUES(?,?,?)", (weekday,start_time,end_time))
            elif path.endswith("/delete"):
                try: wid = int(form.get("id", "0"))
                except ValueError: wid = 0
                con.execute("DELETE FROM weekly_availability WHERE id=?", (wid,))
            elif path.endswith("/block"):
                d = clamp(form.get("date"), 10); reason = clamp(form.get("reason"), 120)
                try: datetime.strptime(d, "%Y-%m-%d")
                except ValueError: return respond(start_response, environ, "Invalid date", "400 Bad Request", "text/plain; charset=utf-8", sensitive=True)
                con.execute("INSERT INTO blocked_dates(date,reason) VALUES(?,?) ON CONFLICT(date) DO UPDATE SET reason=excluded.reason", (d,reason))
            else:
                d = clamp(form.get("date"), 10)
                con.execute("DELETE FROM blocked_dates WHERE date=?", (d,))
            con.commit()
        finally:
            con.close()
        return redirect(start_response, environ, "/admin")

    m_appt = re.fullmatch(r"/admin/appointments/(\d+)/release", path)
    if method == "POST" and m_appt:
        sess = admin_session(environ)
        if not sess:
            return redirect(start_response, environ, "/admin/login")
        form = read_form(environ)
        if not validate_admin_csrf(environ, form):
            return respond(start_response, environ, "Invalid CSRF token", "403 Forbidden", "text/plain; charset=utf-8", sensitive=True)
        con = db_conn(); con.execute("UPDATE appointments SET status='cancelled' WHERE id=?", (int(m_appt.group(1)),)); con.commit(); con.close()
        return redirect(start_response, environ, "/admin")

    if method == "POST" and path == "/admin/students/create":
        sess = admin_session(environ)
        if not sess:
            return redirect(start_response, environ, "/admin/login")
        form = read_form(environ)
        if not validate_admin_csrf(environ, form):
            return respond(start_response, environ, "Invalid CSRF token", "403 Forbidden", "text/plain; charset=utf-8", sensitive=True)
        name = clamp(form.get("name"), 120); email = clamp(form.get("email", "").lower(), 254); password = form.get("password", "")
        if not name or not EMAIL_RE.match(email) or len(password) < 10:
            return respond(start_response, environ, "Invalid student account details", "400 Bad Request", "text/plain; charset=utf-8", sensitive=True)
        salt, pw_hash = hash_password(password)
        try:
            con = db_conn(); con.execute("INSERT INTO users(name,email,salt,password_hash,current_score,target_score) VALUES(?,?,?,?,?,?)", (name,email,salt,pw_hash,clamp(form.get("current_score"),3) or None,clamp(form.get("target_score"),3) or None)); con.commit(); con.close()
        except (sqlite3.IntegrityError, psycopg.IntegrityError if psycopg else sqlite3.IntegrityError):
            return respond(start_response, environ, "A student account with that email already exists.", "409 Conflict", "text/plain; charset=utf-8", sensitive=True)
        return redirect(start_response, environ, "/admin")

    return respond(start_response, environ, "Not found", "404 Not Found", "text/plain; charset=utf-8")


def app(environ, start_response):
    try:
        return route(environ, start_response)
    except Exception:
        log.exception("Unhandled request error")
        return respond(start_response, environ, "Internal server error", "500 Internal Server Error", "text/plain; charset=utf-8", sensitive=True)


init_db()

if __name__ == "__main__":
    host = os.environ.get("HOST", "127.0.0.1")
    print(f"Math with Pedro dev server: http://{host}:{PORT}")
    print(f"Database: {DB_PATH}")
    with make_server(host, PORT, app) as httpd:
        httpd.serve_forever()
