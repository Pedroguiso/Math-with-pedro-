# Launch Checklist

## Hosting + security
- [ ] Persistent disk/volume attached.
- [ ] `DATA_DIR` points to that volume.
- [ ] `PRODUCTION=1`.
- [ ] Strong `SECRET_KEY`.
- [ ] Strong `ADMIN_PASSWORD`.
- [ ] `LEAD_NOTIFY_TO` configured.
- [ ] SMTP configured and tested.
- [ ] `TRUST_PROXY=1` behind the production HTTPS proxy.
- [ ] Real domain connected and HTTPS working.

## Availability — required before traffic
- [ ] Log in to `/admin`.
- [ ] Review the preloaded recurring weekly availability and adjust it if needed.
- [ ] Block dates you already know you cannot work.
- [ ] Open `/apply` and confirm the next two workweeks + Sundays, booked blocks, and available start times are correct.
- [ ] Confirm the times are correct in Eastern Time (Orlando).

## Full booking test
- [ ] Book one test appointment from your phone.
- [ ] Confirm parent name, email, phone, student name, and session time appear in `/admin`.
- [ ] Confirm the booked/overlapping slot disappears from public availability.
- [ ] Confirm Pedro receives the booking alert.
- [ ] Confirm the parent receives the booking confirmation.
- [ ] Confirm `(407) 580-2652` is clickable for text questions.
- [ ] Release the test slot in `/admin` afterward.
- [ ] Export CSV once to verify backup access.

## Outreach tracking
Use a different `utm_source` for each community or partner.

Example:

`https://YOURDOMAIN.com/?utm_source=windermere_soccer&utm_medium=partnership&utm_campaign=fall_sat`

## Bilingual QA
- [ ] Open `/` and confirm EN | PT switch works.
- [ ] Open `/pt/` directly and confirm the full marketing page is in Brazilian Portuguese.
- [ ] Submit one Portuguese test booking at `/pt/apply` and confirm the lead is marked PT in `/admin`.
- [ ] Confirm the Portuguese parent confirmation email is in Portuguese.
- [ ] Confirm English and Portuguese calendars show the same booked slots.
