
## V16 quick-launch note

Email is optional at first deploy. Bookings are still stored in the persistent database and visible in `/admin`. Add SMTP variables later to enable automatic parent confirmations and owner notifications.

# Math with Pedro — launch build

## Quick preview
Unzip the folder and double-click **index.html**. The design, images, mobile layout, menu, and a visual demo of the booking scheduler work directly from the folder.

For real availability, lead capture, email notifications, admin tools, and student login, deploy the Python app.

## Current offer
- **4-Week SAT Math Accelerator — $200** for four private 60-minute sessions.
- **Free 50-minute first Accelerator session** before payment.
- **Single 60-minute SAT Math session — $70** as the flexible alternative.

## Booking system
The booking page is now a real one-page scheduler:

1. Parent/guardian name
2. Email
3. Phone number
4. Student first name
5. Choose an available day
6. Choose an available time
7. Book

No SAT score fields and no multi-step form.

The public scheduler uses 15-minute start increments with a compact **day → hour → minutes** picker. It starts with tomorrow (no same-day bookings), shows the next two workweeks plus two Sundays, and prevents overlapping website bookings. Availability is managed in **Eastern Time (Orlando)**.

The admin dashboard lets you:
- add recurring weekly availability windows;
- delete recurring availability windows;
- block specific dates;
- release a booked slot if needed;
- review upcoming bookings;
- see parent email + phone number;
- mark leads New / Contacted / Scheduled / Converted / Closed;
- resend confirmation emails;
- export leads to CSV;
- create student portal accounts.

**Important:** V9 includes Pedro's current recurring weekly schedule. Review `/admin` and the public `/apply` calendar before sharing the link, especially after any schedule change.

## Direct contact
The site displays Pedro's direct text number for parents with questions:

**(407) 580-2652**

It appears on the booking page and in the site footer. Booking confirmation emails also include it.

## Local server test

```bash
ADMIN_PASSWORD='your-test-password' python app.py
```

Open `http://127.0.0.1:8000` and `/admin`.

SMTP is optional locally. Leads/bookings are stored even if email is not configured.

## Production requirements
With `PRODUCTION=1`, the app refuses to start unless the critical production settings are configured:

- `SECRET_KEY`
- `ADMIN_PASSWORD`
- `DATA_DIR`
- `LEAD_NOTIFY_TO`
- `SMTP_HOST`
- `SMTP_FROM` or `SMTP_USER`

Production can use Render Postgres through `DATABASE_URL` (recommended) or SQLite on a persistent disk through `DATA_DIR`.

## Email
A successful booking is written to the database first, then the app attempts:
- an instant notification email to Pedro;
- a booking confirmation email to the parent.

If email fails, the booking remains stored and visible in `/admin`.

## Outreach attribution
UTM values from outreach links are preserved into the booking record.

Example:

```text
https://YOURDOMAIN.com/?utm_source=windermere_soccer&utm_medium=partnership&utm_campaign=fall_sat
```

## Production command

```bash
gunicorn --workers 1 --threads 4 --timeout 30 --bind 0.0.0.0:$PORT app:app
```

A `render.yaml`, `Procfile`, `Dockerfile`, and `DEPLOY_RENDER.md` are included.

## Bilingual URLs

The public conversion funnel is bilingual and shares one backend/calendar:

- English homepage: `/`
- Portuguese homepage: `/pt/`
- English booking: `/apply`
- Portuguese booking: `/pt/apply`
- Portuguese confirmation and privacy pages remain under `/pt/`.

Use the `/pt/` URL when sending the site to Brazilian families. The EN | PT switch in the header preserves campaign/query parameters when possible.


## V13 credibility update
- Added Pedro's If You Foundation high-school tutoring photo and origin story to EN/PT homepages.
- Added a text-only University of Central Florida / Mechanical Engineering academic credential (no official UCF logo artwork).
- Added dedicated mobile versions of the trust-story section.


## V15: UCF credibility mark
The EN and PT homepages display UCF's official non-athletics Tab mark in Pedro's academic credential card. The image is loaded directly from UCF's public brand asset host and is paired with the full University of Central Florida name and Pedro's Mechanical Engineering student status.


## V15 mobile refinement
- Enlarged and centered Pedro's circular portrait in the mobile Meet Pedro section for stronger personal credibility.


## V17 hosting update
- Added PostgreSQL support through `DATABASE_URL` so bookings persist on Render without a mounted disk.
- Local development still falls back to SQLite.
