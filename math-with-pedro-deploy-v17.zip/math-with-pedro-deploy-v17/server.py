from app import app, PORT
from wsgiref.simple_server import make_server
import os

if __name__ == '__main__':
    host = os.environ.get('HOST','127.0.0.1')
    print(f'Math with Pedro dev server: http://{host}:{PORT}')
    with make_server(host, PORT, app) as httpd:
        httpd.serve_forever()
